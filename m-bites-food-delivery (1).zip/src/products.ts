export const products = [
  // PIZZA
  { id: 101, name: 'Truffle Burrata Pizza', price: 499, disc: 15, rating: 4.9, category: 'Pizza', isVeg: true, image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=400&h=400&fit=crop' },
  { id: 102, name: 'Classic Pepperoni', price: 349, disc: 10, rating: 4.7, category: 'Pizza', isVeg: false, image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=400&h=400&fit=crop' },
  { id: 103, name: 'Margherita Fresca', price: 299, disc: 20, rating: 4.5, category: 'Pizza', isVeg: true, image: 'https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?w=400&h=400&fit=crop' },
  { id: 104, name: 'BBQ Chicken Pizza', price: 399, disc: 15, rating: 4.6, category: 'Pizza', isVeg: false, image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop' },
  { id: 105, name: 'Spicy Veggie Supreme', price: 349, disc: 12, rating: 4.4, category: 'Pizza', isVeg: true, image: 'https://images.unsplash.com/photo-1590947132387-155cc02f3212?w=400&h=400&fit=crop' },
  { id: 106, name: 'Four Cheese Delight', price: 450, disc: 20, rating: 4.8, category: 'Pizza', isVeg: true, image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=400&fit=crop' },
  { id: 107, name: 'Mushroom & Olive', price: 379, disc: 10, rating: 4.3, category: 'Pizza', isVeg: true, image: 'https://images.unsplash.com/photo-1544982503-9f984c14501a?w=400&h=400&fit=crop' },
  { id: 108, name: 'Prosciutto & Arugula', price: 500, disc: 25, rating: 4.9, category: 'Pizza', isVeg: false, image: 'https://images.unsplash.com/photo-1594007654729-407eedc4be65?w=400&h=400&fit=crop' },
  { id: 109, name: 'Hawaiian Bliss', price: 320, disc: 15, rating: 4.1, category: 'Pizza', isVeg: false, image: 'https://image.pollinations.ai/prompt/Hawaiian%20Bliss%20Pizza%20food%20photography' },
  { id: 110, name: 'Pesto Chicken Crust', price: 420, disc: 12, rating: 4.6, category: 'Pizza', isVeg: false, image: 'https://images.unsplash.com/photo-1576458088443-04a19bb13da6?w=400&h=400&fit=crop' },

  // BURGERS
  { id: 201, name: 'A5 Wagyu Signature', price: 499, disc: 25, rating: 4.9, category: 'Burgers', isVeg: false, image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=400&fit=crop' },
  { id: 202, name: 'Classic Cheeseburger', price: 199, disc: 5, rating: 4.5, category: 'Burgers', isVeg: false, image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=400&h=400&fit=crop' },
  { id: 203, name: 'Crispy Fried Chicken', price: 249, disc: 18, rating: 4.7, category: 'Burgers', isVeg: false, image: 'https://images.unsplash.com/photo-1512152272829-e3139592d56f?w=400&h=400&fit=crop' },
  { id: 204, name: 'Black Bean Vegan', price: 219, disc: 12, rating: 4.4, category: 'Burgers', isVeg: true, image: 'https://images.unsplash.com/photo-1520072959219-c595dc870360?w=400&h=400&fit=crop' },
  { id: 205, name: 'Spicy Jalapeno Beef', price: 299, disc: 20, rating: 4.6, category: 'Burgers', isVeg: false, image: 'https://image.pollinations.ai/prompt/Spicy%20Jalapeno%20Beef%20Burger%20food%20photography' },
  { id: 206, name: 'Double Smash Patty', price: 349, disc: 15, rating: 4.8, category: 'Burgers', isVeg: false, image: 'https://image.pollinations.ai/prompt/Double%20Smash%20Patty%20Burger%20food%20photography' },
  { id: 207, name: 'Truffle Mushroom Burger', price: 399, disc: 22, rating: 4.7, category: 'Burgers', isVeg: true, image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?w=400&h=400&fit=crop' },
  { id: 208, name: 'BBQ Pulled Pork', price: 379, disc: 10, rating: 4.5, category: 'Burgers', isVeg: false, image: 'https://images.unsplash.com/photo-1525648199074-cee30ba79a4a?w=400&h=400&fit=crop' },
  { id: 209, name: 'Grilled Paneer Tikka', price: 249, disc: 8, rating: 4.3, category: 'Burgers', isVeg: true, image: 'https://images.unsplash.com/photo-1603064752734-4c48eff53d05?w=400&h=400&fit=crop' },
  { id: 210, name: 'Blue Cheese Bacon', price: 429, disc: 15, rating: 4.6, category: 'Burgers', isVeg: false, image: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=400&fit=crop' },

  // HEALTHY
  { id: 301, name: 'Avocado Quinoa Salad', price: 349, disc: 12, rating: 4.8, category: 'Healthy', isVeg: true, image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400&h=400&fit=crop' },
  { id: 302, name: 'Acai Superfruit Bowl', price: 299, disc: 15, rating: 4.7, category: 'Healthy', isVeg: true, image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=400&h=400&fit=crop' },
  { id: 303, name: 'Grilled Salmon Platter', price: 499, disc: 20, rating: 4.9, category: 'Healthy', isVeg: false, image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=400&h=400&fit=crop' },
  { id: 304, name: 'Roasted Veggie Wrap', price: 199, disc: 8, rating: 4.4, category: 'Healthy', isVeg: true, image: 'https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=400&h=400&fit=crop' },
  { id: 305, name: 'Green Detox Smoothie', price: 149, disc: 10, rating: 4.6, category: 'Healthy', isVeg: true, image: 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=400&h=400&fit=crop' },
  { id: 306, name: 'Kale & Peanut Salad', price: 249, disc: 5, rating: 4.3, category: 'Healthy', isVeg: true, image: 'https://images.unsplash.com/photo-1505253716362-afaea1d3d1af?w=400&h=400&fit=crop' },
  { id: 307, name: 'Protein Egg Bowl', price: 229, disc: 10, rating: 4.7, category: 'Healthy', isVeg: false, image: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=400&h=400&fit=crop' },
  { id: 308, name: 'Tofu Poke Bowl', price: 379, disc: 15, rating: 4.5, category: 'Healthy', isVeg: true, image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=400&fit=crop' },
  { id: 309, name: 'Greek Chicken Salad', price: 349, disc: 12, rating: 4.8, category: 'Healthy', isVeg: false, image: 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?w=400&h=400&fit=crop' },
  { id: 310, name: 'Chia Seed Pudding', price: 179, disc: 8, rating: 4.4, category: 'Healthy', isVeg: true, image: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400&h=400&fit=crop' },

  // DRINKS
  { id: 401, name: 'Matcha Boba Float', price: 249, disc: 10, rating: 4.8, category: 'Drinks', isVeg: true, image: 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&h=400&fit=crop' },
  { id: 402, name: 'Mango Passion Spritz', price: 199, disc: 15, rating: 4.5, category: 'Drinks', isVeg: true, image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400&h=400&fit=crop' },
  { id: 403, name: 'Classic Mojito', price: 149, disc: 20, rating: 4.3, category: 'Drinks', isVeg: true, image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=400&h=400&fit=crop' },
  { id: 404, name: 'Berry Lemonade', price: 129, disc: 12, rating: 4.6, category: 'Drinks', isVeg: true, image: 'https://images.unsplash.com/photo-1527661591475-527312dd65f5?w=400&h=400&fit=crop' },
  { id: 405, name: 'Iced Caramel Frappe', price: 219, disc: 15, rating: 4.7, category: 'Drinks', isVeg: true, image: 'https://image.pollinations.ai/prompt/Iced%20Caramel%20Frappe%20drink%20photography' },
  { id: 406, name: 'Fresh Orange Juice', price: 110, disc: 10, rating: 4.2, category: 'Drinks', isVeg: true, image: 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=400&h=400&fit=crop' },
  { id: 407, name: 'Kombucha Ginger', price: 169, disc: 18, rating: 4.4, category: 'Drinks', isVeg: true, image: 'https://images.unsplash.com/photo-1556881286-fc6915169721?w=400&h=400&fit=crop' },
  { id: 408, name: 'Coconut Water Shake', price: 159, disc: 12, rating: 4.5, category: 'Drinks', isVeg: true, image: 'https://images.unsplash.com/photo-1524156868115-e696b44983db?w=400&h=400&fit=crop' },
  { id: 409, name: 'Pineapple Margarita', price: 299, disc: 25, rating: 4.9, category: 'Drinks', isVeg: true, image: 'https://images.unsplash.com/photo-1536935338788-846bb9981813?w=400&h=400&fit=crop' },
  { id: 410, name: 'Watermelon Cooler', price: 139, disc: 15, rating: 4.7, category: 'Drinks', isVeg: true, image: 'https://image.pollinations.ai/prompt/Watermelon%20Cooler%20drink%20photography' },

  // DESSERTS
  { id: 501, name: 'Dark Choco Lava Cake', price: 249, disc: 20, rating: 4.9, category: 'Desserts', isVeg: true, image: 'https://images.unsplash.com/photo-1624353365286-3f8d62daad51?w=400&h=400&fit=crop' },
  { id: 502, name: 'New York Cheesecake', price: 349, disc: 15, rating: 4.8, category: 'Desserts', isVeg: true, image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=400&h=400&fit=crop' },
  { id: 503, name: 'Vanilla Bean Gelato', price: 149, disc: 10, rating: 4.5, category: 'Desserts', isVeg: true, image: 'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=400&h=400&fit=crop' },
  { id: 504, name: 'Tiramisu Layer Cake', price: 399, disc: 18, rating: 4.7, category: 'Desserts', isVeg: true, image: 'https://image.pollinations.ai/prompt/Tiramisu%20Layer%20Cake%20dessert%20food%20photography' },
  { id: 505, name: 'Macarons Box (6 pcs)', price: 499, disc: 25, rating: 4.6, category: 'Desserts', isVeg: true, image: 'https://images.unsplash.com/photo-1569864358642-9d1684040f43?w=400&h=400&fit=crop' },
  { id: 506, name: 'Pistachio Baklava', price: 299, disc: 12, rating: 4.4, category: 'Desserts', isVeg: true, image: 'https://image.pollinations.ai/prompt/Pistachio%20Baklava%20dessert%20food%20photography' },
  { id: 507, name: 'Strawberry Tart', price: 229, disc: 15, rating: 4.8, category: 'Desserts', isVeg: true, image: 'https://images.unsplash.com/photo-1464305795204-6f5bbfc7fb81?w=400&h=400&fit=crop' },
  { id: 508, name: 'Hazelnut Brownie', price: 169, disc: 10, rating: 4.6, category: 'Desserts', isVeg: true, image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=400&h=400&fit=crop' },
  { id: 509, name: 'Red Velvet Cupcake', price: 129, disc: 8, rating: 4.3, category: 'Desserts', isVeg: true, image: 'https://images.unsplash.com/photo-1614707267537-b85aaf00c4b7?w=400&h=400&fit=crop' },
  { id: 510, name: 'Cream Crème Brûlée', price: 289, disc: 12, rating: 4.7, category: 'Desserts', isVeg: true, image: 'https://images.unsplash.com/photo-1473256599800-b48c7c88cd7e?w=400&h=400&fit=crop' },

  // SUSHI
  { id: 601, name: 'Dragon Sushi Roll', price: 450, disc: 15, rating: 4.8, category: 'Sushi', isVeg: false, image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=400&h=400&fit=crop' },
  { id: 602, name: 'Spicy Tuna Maki', price: 350, disc: 10, rating: 4.6, category: 'Sushi', isVeg: false, image: 'https://images.unsplash.com/photo-1553621042-f6e147245754?w=400&h=400&fit=crop' },
  { id: 603, name: 'Salmon Nigiri (4 pcs)', price: 400, disc: 20, rating: 4.9, category: 'Sushi', isVeg: false, image: 'https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=400&h=400&fit=crop' },
  { id: 604, name: 'Avocado Veg Roll', price: 250, disc: 12, rating: 4.3, category: 'Sushi', isVeg: true, image: 'https://image.pollinations.ai/prompt/Avocado%20Veg%20Sushi%20Roll%20food%20photography' },
  { id: 605, name: 'Tempura Prawn Roll', price: 420, disc: 18, rating: 4.7, category: 'Sushi', isVeg: false, image: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=400&h=400&fit=crop' },
  { id: 606, name: 'Eel Unagi Roll', price: 480, disc: 15, rating: 4.8, category: 'Sushi', isVeg: false, image: 'https://images.unsplash.com/photo-1558985250-27a406d64cb3?w=400&h=400&fit=crop' },
  { id: 607, name: 'California Maki', price: 320, disc: 10, rating: 4.5, category: 'Sushi', isVeg: false, image: 'https://images.unsplash.com/photo-1617196034183-421b4917c92d?w=400&h=400&fit=crop' },
  { id: 608, name: 'Rainbow Sushi Platter', price: 500, disc: 25, rating: 4.9, category: 'Sushi', isVeg: false, image: 'https://images.unsplash.com/photo-1628191010210-a59de33e5941?w=400&h=400&fit=crop' },
  { id: 609, name: 'Crispy Spider Roll', price: 390, disc: 12, rating: 4.6, category: 'Sushi', isVeg: false, image: 'https://images.unsplash.com/photo-1563636619-e9143da7973b?w=400&h=400&fit=crop' },
  { id: 610, name: 'Tofu Inari Sushi', price: 220, disc: 8, rating: 4.4, category: 'Sushi', isVeg: true, image: 'https://image.pollinations.ai/prompt/Tofu%20Inari%20Sushi%20food%20photography' },

  // COFFEE
  { id: 701, name: 'Artisanal Cold Brew', price: 229, rating: 4.8, category: 'Coffee', isVeg: true, image: 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=400&h=400&fit=crop' },
  { id: 702, name: 'Caramel Macchiato', price: 249, rating: 4.7, category: 'Coffee', isVeg: true, image: 'https://images.unsplash.com/photo-1485808191679-5f86510681a2?w=400&h=400&fit=crop' },
  { id: 703, name: 'Classic Cappuccino', price: 189, rating: 4.6, category: 'Coffee', isVeg: true, image: 'https://images.unsplash.com/photo-1534778101976-62847782c213?w=400&h=400&fit=crop' },
  { id: 704, name: 'Nitro Cold Brew', price: 299, rating: 4.9, category: 'Coffee', isVeg: true, image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=400&h=400&fit=crop' },
  { id: 705, name: 'Espresso Double Shot', price: 149, rating: 4.5, category: 'Coffee', isVeg: true, image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400&h=400&fit=crop' },
  { id: 706, name: 'Iced Vanilla Latte', price: 239, rating: 4.8, category: 'Coffee', isVeg: true, image: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=400&h=400&fit=crop' },
  { id: 707, name: 'Mocha Frappuccino', price: 269, rating: 4.7, category: 'Coffee', isVeg: true, image: 'https://image.pollinations.ai/prompt/Mocha%20Frappuccino%20coffee%20drink%20photography' },
  { id: 708, name: 'Hazelnut Cortado', price: 199, rating: 4.6, category: 'Coffee', isVeg: true, image: 'https://images.unsplash.com/photo-1551024601-bec78aea704b?w=400&h=400&fit=crop' },
  { id: 709, name: 'Pour Over V60', price: 279, rating: 4.9, category: 'Coffee', isVeg: true, image: 'https://images.unsplash.com/photo-1497935586351-b67a49e012bf?w=400&h=400&fit=crop' },
  { id: 710, name: 'Affogato Coffee', price: 349, rating: 4.8, category: 'Coffee', isVeg: true, image: 'https://image.pollinations.ai/prompt/Affogato%20Coffee%20cup%20photography' },
  
  // PASTA
  { id: 801, name: 'Classic Carbonara', price: 350, rating: 4.8, category: 'Pasta', isVeg: false, image: 'https://images.unsplash.com/photo-1612874742237-6526221588e3?w=400&h=400&fit=crop' },
  { id: 802, name: 'Penne Arrabbiata', price: 290, rating: 4.5, category: 'Pasta', isVeg: true, image: 'https://images.unsplash.com/photo-1555949258-eb67b1ef0ceb?w=400&h=400&fit=crop' },
  { id: 803, name: 'Truffle Mushroom Fettuccine', price: 450, rating: 4.9, category: 'Pasta', isVeg: true, image: 'https://images.unsplash.com/photo-1622973536968-3ead9e780960?w=400&h=400&fit=crop' },
  { id: 804, name: 'Spaghetti Bolognese', price: 380, rating: 4.7, category: 'Pasta', isVeg: false, image: 'https://images.unsplash.com/photo-1626844131082-256783844137?w=400&h=400&fit=crop' },
  { id: 805, name: 'Seafood Linguine', price: 490, rating: 4.8, category: 'Pasta', isVeg: false, image: 'https://images.unsplash.com/photo-1563379926898-05f4575a45d8?w=400&h=400&fit=crop' },

  // TACOS
  { id: 901, name: 'Carne Asada Tacos', price: 250, rating: 4.7, category: 'Tacos', isVeg: false, image: 'https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?w=400&h=400&fit=crop' },
  { id: 902, name: 'Baja Fish Tacos', price: 300, rating: 4.8, category: 'Tacos', isVeg: false, image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=400&h=400&fit=crop' },
  { id: 903, name: 'Spicy Mushroom Tacos', price: 220, rating: 4.5, category: 'Tacos', isVeg: true, image: 'https://images.unsplash.com/photo-1615870216519-2f9fa575fa5c?w=400&h=400&fit=crop' },
  { id: 904, name: 'Al Pastor Tacos', price: 270, rating: 4.9, category: 'Tacos', isVeg: false, image: 'https://images.unsplash.com/photo-1599974579688-8dbdd335c77f?w=400&h=400&fit=crop' },
  { id: 905, name: 'Black Bean & Corn Tacos', price: 200, rating: 4.4, category: 'Tacos', isVeg: true, image: 'https://images.unsplash.com/photo-1564834724105-918b73d1b9e0?w=400&h=400&fit=crop' },

  // SALADS
  { id: 1001, name: 'Classic Caesar Salad', price: 250, rating: 4.6, category: 'Salads', isVeg: true, image: 'https://images.unsplash.com/photo-1550304943-4f24f54ddde9?w=400&h=400&fit=crop' },
  { id: 1002, name: 'Greek Feta Salad', price: 280, rating: 4.7, category: 'Salads', isVeg: true, image: 'https://image.pollinations.ai/prompt/Greek%20Feta%20Salad%20food%20photography' },
  { id: 1003, name: 'Quinoa & Avocado Bowl', price: 320, rating: 4.9, category: 'Salads', isVeg: true, image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=400&fit=crop' },
  { id: 1004, name: 'Grilled Chicken Salad', price: 350, rating: 4.8, category: 'Salads', isVeg: false, image: 'https://images.unsplash.com/photo-1529312266912-b33cfce2eefd?w=400&h=400&fit=crop' },
  { id: 1005, name: 'Caprese Salad', price: 290, rating: 4.5, category: 'Salads', isVeg: true, image: 'https://images.unsplash.com/photo-1592417817098-8fd3d9eb14a5?w=400&h=400&fit=crop' },

  // ICE CREAM
  { id: 1101, name: 'Vanilla Bean Gelato', price: 180, disc: 10, rating: 4.7, category: 'Ice Cream', isVeg: true, image: 'https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?w=400&h=400&fit=crop' },
  { id: 1102, name: 'Dark Chocolate Fudge', price: 220, disc: 15, rating: 4.9, category: 'Ice Cream', isVeg: true, image: 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?w=400&h=400&fit=crop' },
  { id: 1103, name: 'Strawberry Swirl', price: 190, disc: 12, rating: 4.6, category: 'Ice Cream', isVeg: true, image: 'https://image.pollinations.ai/prompt/Strawberry%20Swirl%20ice%20cream%20food%20photography' },
  { id: 1104, name: 'Mint Chocolate Chip', price: 210, disc: 8, rating: 4.5, category: 'Ice Cream', isVeg: true, image: 'https://images.unsplash.com/photo-1553177595-4de2bb0842b9?w=400&h=400&fit=crop' },
  { id: 1105, name: 'Salted Caramel Crunch', price: 250, disc: 15, rating: 4.8, category: 'Ice Cream', isVeg: true, image: 'https://images.unsplash.com/photo-1464965911861-746a04b4bca6?w=400&h=400&fit=crop' }
];

// Reusable function to shuffle elements in a consistent or random manner
export const getMixedProducts = () => {
  // Return products as they are to maintain stable order for UI interactions
  return [...products];
};
