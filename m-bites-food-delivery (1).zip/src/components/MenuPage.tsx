import { ArrowLeft, Star, Clock, Info, Search, Share2, Heart, Plus, Minus } from 'lucide-react';
import { getFallbackImage } from '../utils/fallbackImage';
import { menuItems } from '../data';
import { toast } from 'react-hot-toast';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  isVeg: boolean;
  image?: string;
}

interface MenuPageProps {
  restaurant: any;
  onBack: () => void;
  cartItems: CartItem[];
  wishlistIds: number[];
  onAddToCart: (item: any) => void;
  onBuyNow?: (item: any) => void;
  onProductClick?: (item: any) => void;
  onUpdateQuantity: (id: number, delta: number) => void;
  onToggleWishlist: (id: number) => void;
  onSearch: () => void;
}

export default function MenuPage({ restaurant, onBack, cartItems, wishlistIds, onAddToCart, onBuyNow, onProductClick, onUpdateQuantity, onToggleWishlist, onSearch }: MenuPageProps) {
  const getCartItemQuantity = (id: number) => {
    const item = cartItems.find(item => item.id === id);
    return item ? item.quantity : 0;
  };

  return (
    <div className="bg-gray-50 dark:bg-[#0a0a0a] min-h-screen pb-20 text-gray-900 dark:text-gray-100 transition-colors duration-500">
      {/* Header / Breadcrumb area */}
      <div className="sticky top-20 z-40 bg-white/80 dark:bg-[#0a0a0a]/80 backdrop-blur-xl border-b border-black/5 dark:border-white/5 px-4 py-3 flex items-center justify-between shadow-sm dark:shadow-[0_4px_30px_rgba(0,0,0,0.1)]">
        <button onClick={onBack} className="p-2 -ml-2 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:text-white hover:bg-black/5 dark:bg-white/10 rounded-full transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div className="flex gap-3">
          <button 
            onClick={onSearch}
            className="p-2 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:text-white hover:bg-black/5 dark:bg-white/10 rounded-full transition-colors"
          >
            <Search className="w-5 h-5" />
          </button>
          <button 
            onClick={() => toast('Link copied to clipboard!', { icon: '🔗' })}
            className="p-2 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:text-white hover:bg-black/5 dark:bg-white/10 rounded-full transition-colors"
          >
            <Share2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Restaurant Info */}
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-3xl font-black text-gray-900 dark:text-white mb-1 tracking-tight">{restaurant.name}</h1>
            <p className="text-gray-600 dark:text-gray-400 text-sm mb-2">{restaurant.cuisines.join(', ')}</p>
            <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">New York • 2.5 km</p>
            <div className="flex items-center gap-4 text-sm font-medium text-gray-700 dark:text-gray-300">
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4 text-[#E23744]" />
                {restaurant.deliveryTime}
              </div>
              <div className="w-1.5 h-1.5 bg-gray-600 rounded-full"></div>
              <div>{restaurant.priceForTwo}</div>
            </div>
          </div>
          <div className="flex flex-col items-center glass-card rounded-xl p-3">
            <div className="flex items-center gap-1 text-green-500 font-bold text-lg mb-1">
              {restaurant.rating} <Star className="w-4 h-4 fill-current" />
            </div>
            <div className="text-[10px] text-gray-500 font-bold uppercase tracking-wider border-t border-black/10 dark:border-white/10 pt-2 text-center w-full">
              10K+ Ratings
            </div>
          </div>
        </div>

        {/* Offers */}
        {restaurant.offer && (
          <div className="flex items-center gap-3 p-4 border border-blue-500/20 rounded-2xl mb-8 bg-blue-900/20">
            <div className="bg-blue-600 text-gray-900 dark:text-white p-1.5 rounded-full shadow-[0_0_10px_rgba(37,99,235,0.5)]">
              <Info className="w-4 h-4" />
            </div>
            <div>
              <p className="font-bold text-blue-100 text-sm">{restaurant.offer}</p>
              <p className="text-xs text-blue-300">Use code NEXRADEL at checkout</p>
            </div>
          </div>
        )}

        <div className="border-b border-black/5 dark:border-white/5 -mx-4 sm:mx-0 mb-8"></div>

        {/* Menu Items */}
        <div>
          <h2 className="text-2xl font-black text-gray-900 dark:text-white mb-6 flex items-center gap-2">
            Recommended <span className="text-sm font-medium text-gray-500">({menuItems.length})</span>
          </h2>
          
          <div className="flex flex-col gap-8">
            {menuItems.map((item) => {
              const quantity = getCartItemQuantity(item.id);
              const originalPrice = item.disc ? Math.round(item.price / (1 - item.disc / 100)) : item.price;
              
              return (
                <div 
                  key={item.id} 
                  className="flex justify-between gap-4 pb-8 border-b border-black/5 dark:border-white/5 last:border-0 group cursor-pointer"
                  onClick={() => onProductClick?.(item)}
                >
                  {/* Item Details */}
                  <div className="flex-1">
                    {/* Veg/Non-veg icon */}
                    <div className={`w-4 h-4 border rounded-sm flex items-center justify-center mb-2 ${item.isVeg ? 'border-green-500' : 'border-red-500'}`}>
                      <div className={`w-2 h-2 rounded-full ${item.isVeg ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    </div>
                    
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1 group-hover:text-[#E23744] transition-colors flex justify-between pr-4 relative">
                      {item.name}
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleWishlist?.(item.id);
                        }}
                        className={`absolute right-0 top-0 p-1.5 rounded-full transition-colors ${wishlistIds.includes(item.id) ? 'text-[#E23744] bg-red-500/10' : 'text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/10'}`}
                      >
                       <Heart className={`w-4 h-4 ${wishlistIds.includes(item.id) ? 'fill-current' : ''}`} />
                      </button>
                    </h3>

                    {/* Rating & Percentage inline */}
                    <div className="flex items-center gap-1.5 mb-1.5 text-xs">
                      <div className="flex items-center gap-0.5 bg-green-600 text-white px-1.5 py-0.5 rounded font-bold shadow-sm">
                        {item.rating} <Star className="w-2.5 h-2.5 fill-current" />
                      </div>
                      <span className="text-gray-500 font-medium">{item.ratingsCount} ratings</span>
                    </div>

                    <div className="flex items-center gap-2 mb-2">
                      <p className="font-black text-gray-900 dark:text-white text-lg">₹{item.price.toFixed(2)}</p>
                      {item.disc && (
                        <>
                          <span className="text-sm text-gray-400 line-through">₹{originalPrice.toFixed(2)}</span>
                          <span className="text-[10px] font-black bg-green-500/10 text-green-600 dark:text-green-400 px-2 py-0.5 rounded-full border border-green-500/20 uppercase tracking-widest">
                            {item.disc}% OFF
                          </span>
                        </>
                      )}
                    </div>
                    
                    <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  {/* Item Image & Add Button */}
                  <div className="relative w-[130px] shrink-0">
                    <div className="w-[130px] h-[130px] rounded-2xl overflow-hidden shadow-lg shadow-black/40 border border-black/5 dark:border-white/5">
                      <img 
                        src={item.image} 
                        alt={item.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          e.currentTarget.src = getFallbackImage(item.id);
                          e.currentTarget.onerror = null;
                        }}
                      />
                    </div>
                    
                    <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-[110px] flex flex-col gap-2">
                      {quantity > 0 ? (
                        <div className="bg-white dark:bg-[#141414] text-green-600 dark:text-green-500 font-bold text-sm rounded-xl shadow-lg border border-green-500/30 flex items-center justify-between overflow-hidden scale-90">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              onUpdateQuantity(item.id, -1);
                            }}
                            className="px-3 py-2 hover:bg-gray-100 dark:hover:bg-white/5 transition-colors"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span>{quantity}</span>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              onUpdateQuantity(item.id, 1);
                            }}
                            className="px-3 py-2 hover:bg-gray-100 dark:hover:bg-white/5 transition-colors"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex flex-col gap-1.5 items-center">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              onAddToCart(item);
                            }}
                            className="w-full bg-white dark:bg-[#141414] text-green-600 dark:text-green-500 font-bold text-xs py-2 rounded-xl shadow-lg border border-black/10 dark:border-white/10 hover:border-green-500/50 hover:bg-gray-50 dark:hover:bg-[#1a1a1a] transition-all active:scale-95 uppercase tracking-wide"
                          >
                            Add
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onBuyNow?.(item);
                            }}
                            className="w-full bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-500 hover:to-yellow-600 text-black font-black text-[9px] py-1.5 rounded-lg active:scale-95 transition-all shadow-[0_4px_14px_rgba(251,191,36,0.3)] uppercase"
                          >
                            Buy Now
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
