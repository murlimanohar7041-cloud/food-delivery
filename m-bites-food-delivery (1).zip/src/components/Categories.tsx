import { categories } from '../data';
import { getFallbackImage } from '../utils/fallbackImage';

interface CategoriesProps {
  setView: (view: any) => void;
  setSearchQuery: (q: string) => void;
}

export default function Categories({ setView, setSearchQuery }: CategoriesProps) {
  return (
    <section className="py-10 bg-gray-50 dark:bg-[#0a0a0a] transition-colors duration-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-[24px] font-bold text-gray-900 dark:text-white">
            Inspiration for your first order
          </h2>
        </div>
        
        <div className="flex overflow-x-auto hide-scrollbar gap-8 pb-4 -mx-4 px-4 sm:mx-0 sm:px-0">
          {categories.map((category) => (
            <div 
              key={category.id}
              onClick={() => {
                setSearchQuery(category.name);
                setView('search');
              }}
              className="flex flex-col items-center gap-3 min-w-[80px] cursor-pointer group"
            >
              <div className="w-20 h-20 rounded-full overflow-hidden bg-white dark:bg-[#141414] border border-gray-200 dark:border-white/5 p-1 transition-all duration-300 group-hover:scale-110 group-hover:border-[#E23744] dark:group-hover:border-[#E23744] hover:shadow-[0_4px_20px_rgba(226,55,68,0.2)] dark:hover:shadow-[0_0_15px_rgba(226,55,68,0.4)]">
                <img 
                  src={category.image} 
                  alt={category.name}
                  className="w-full h-full object-cover rounded-full group-hover:brightness-110 transition-all"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    e.currentTarget.src = getFallbackImage(category.id);
                    e.currentTarget.onerror = null;
                  }}
                />
              </div>
              <span className="text-[14px] font-medium text-gray-700 dark:text-gray-300 group-hover:text-gray-900 dark:text-white transition-colors">
                {category.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
