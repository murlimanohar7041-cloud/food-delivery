import { CheckCircle2, Home, MapPin, Truck, FileText, Download, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { Order } from './OrdersPage';
import InvoiceModal from './InvoiceModal';

interface SuccessScreenProps {
  order?: Order;
  onBackToHome: () => void;
  onViewOrders?: () => void;
}

export default function SuccessScreen({ order, onBackToHome, onViewOrders }: SuccessScreenProps) {
  const [showInvoice, setShowInvoice] = useState(false);
  const displayOrderId = order?.id || Math.floor(100000000 + Math.random() * 900000000).toString();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#0a0a0a] flex flex-col items-center justify-center p-4">
      <motion.div 
        initial={{ scale: 0.8, opacity: 0, y: 30 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="glass-card rounded-3xl p-8 max-w-md w-full text-center relative overflow-hidden"
      >
        
        {/* Glow effect */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-1/2 bg-green-500/20 blur-[60px] rounded-full pointer-events-none"></div>

        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', delay: 0.2, damping: 12, stiffness: 200 }}
          className="w-24 h-24 bg-green-100 dark:bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_20px_rgba(34,197,94,0.3)] relative z-10 border border-green-500/30"
        >
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.4, type: 'spring' }}
          >
            <CheckCircle2 className="w-12 h-12 text-green-500" />
          </motion.div>
        </motion.div>
        
        <motion.h1 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white mb-2 relative z-10"
        >
          Order Confirmed! 🎉
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-gray-600 dark:text-gray-400 mb-8 font-medium relative z-10"
        >
          Your delicious food is being prepared.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-white dark:bg-[#0a0a0a] rounded-2xl p-4 mb-8 text-left border border-gray-200 dark:border-white/10 relative z-10 shadow-sm"
        >
          <div className="flex justify-between items-center mb-4 pb-4 border-b border-gray-100 dark:border-white/10">
            <span className="text-gray-500 text-sm font-medium">Order ID</span>
            <span className="font-bold text-gray-900 dark:text-white">#{displayOrderId}</span>
          </div>
          <div className="flex items-start gap-3">
            <Truck className="w-5 h-5 text-[#E23744] shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold text-gray-900 dark:text-white mb-1">Estimated Delivery: 35 mins</p>
              <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                Will be delivered to your selected address securely.
              </p>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="flex flex-col gap-3 relative z-10"
        >
          {order && (
            <button 
              onClick={() => setShowInvoice(true)}
              className="w-full bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl py-4 font-bold text-lg border border-blue-200 dark:border-blue-500/20 hover:bg-blue-100 dark:hover:bg-blue-500/20 transition-all flex items-center justify-center gap-2"
            >
              <FileText className="w-5 h-5" />
              View Invoice
            </button>
          )}

          <button 
            onClick={onViewOrders}
            className="w-full bg-gray-100 dark:bg-[#141414] text-gray-900 dark:text-white rounded-xl py-4 font-bold text-lg border border-transparent dark:border-white/10 hover:bg-gray-200 dark:hover:bg-[#1a1a1a] transition-all flex items-center justify-center gap-2"
          >
            Track Order
          </button>
          
          <button 
            onClick={onBackToHome}
            className="w-full bg-gradient-to-r from-[#E23744] to-[#FF5E5E] text-white rounded-xl py-4 font-bold text-lg hover:shadow-[0_0_20px_rgba(226,55,68,0.4)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 relative z-10"
          >
            <Home className="w-5 h-5" />
            Back to Home
          </button>
        </motion.div>
      </motion.div>

      {/* Invoice Modal */}
      {order && <InvoiceModal show={showInvoice} onClose={() => setShowInvoice(false)} order={order} />}
    </div>
  );
}
