import React, { useState, useMemo, useEffect } from 'react';
import { ArrowLeft, Search, Filter, ChevronRight, Package, Truck, CheckCircle2, ChevronDown, MapPin, Clock, Star, HelpCircle, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import InvoiceModal from './InvoiceModal';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  isVeg: boolean;
  image?: string;
}

interface Address {
  firstName?: string;
  lastName?: string;
  email?: string;
  address?: string;
  city?: string;
  zipCode?: string;
  name?: string;
  phone?: string;
  flat?: string;
  area?: string;
}

export interface Order {
  id: string;
  userId?: string;
  userEmail?: string;
  items: CartItem[];
  total: number;
  status: 'Pending' | 'Preparing' | 'Out for Delivery' | 'Delivered' | 'Cancelled';
  date: string;
  address: Address;
  paymentMethod: string;
}

interface OrdersPageProps {
  orders: Order[];
  onBack: () => void;
  isAdmin?: boolean;
}

const ORDER_FILTERS = ['All', 'On the way', 'Delivered', 'Cancelled'];
const TIME_FILTERS = ['Anytime', 'Last 30 days', '2024', '2023'];

export default function OrdersPage({ orders, onBack, isAdmin }: OrdersPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [timeFilter, setTimeFilter] = useState('Anytime');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  // Filter logic
  const filteredOrders = useMemo(() => {
    return orders.filter(order => {
      const matchesSearch = order.id.toLowerCase().includes(searchQuery.toLowerCase()) || 
        order.items.some(item => item.name.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesStatus = activeFilter === 'All' || 
        (activeFilter === 'On the way' && ['Pending', 'Preparing', 'Out for Delivery'].includes(order.status)) ||
        (activeFilter === 'Delivered' && order.status === 'Delivered') ||
        (activeFilter === 'Cancelled' && order.status === 'Cancelled');

      return matchesSearch && matchesStatus;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [orders, searchQuery, activeFilter]);

  const selectedOrder = useMemo(() => 
    orders.find(o => o.id === selectedOrderId), 
  [orders, selectedOrderId]);

  if (selectedOrderId && selectedOrder) {
    return (
      <OrderDetailView 
        order={selectedOrder} 
        onBack={() => setSelectedOrderId(null)} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#f1f3f6] dark:bg-[#0a0a0a] pb-20 text-gray-900 dark:text-gray-100">
      {/* Header */}
      <div className="bg-white dark:bg-[#141414] border-b border-gray-200 dark:border-white/10 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="p-2 -ml-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-full transition-colors">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-xl font-bold">My Orders</h1>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search your orders here"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 bg-[#f0f2f5] dark:bg-white/5 border-none rounded-sm w-80 text-sm focus:ring-1 focus:ring-[#2874f0] outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      <div className={`max-w-7xl mx-auto px-0 sm:px-4 py-0 sm:py-6 ${isAdmin ? 'lg:flex gap-6' : ''}`}>
        {/* Filters Sidebar (Desktop) - ONLY FOR ADMIN */}
        {isAdmin && (
          <div className="hidden lg:block w-72 shrink-0">
            <div className="bg-white dark:bg-[#141414] rounded shadow-sm overflow-hidden sticky top-24">
              <div className="p-4 border-b border-gray-100 dark:border-white/5 font-bold flex items-center justify-between">
                <span className="text-lg">Filters</span>
              </div>
              
              <div className="p-4 space-y-8">
                <div>
                  <p className="text-xs font-bold uppercase text-gray-400 mb-4 tracking-widest">Order Status</p>
                  <div className="space-y-3">
                    {ORDER_FILTERS.map(f => (
                      <label key={f} className="flex items-center gap-3 cursor-pointer group">
                        <div className={`w-4 h-4 rounded-sm border transition-all flex items-center justify-center ${activeFilter === f ? 'bg-[#2874f0] border-[#2874f0]' : 'border-gray-300 dark:border-gray-600 group-hover:border-gray-400'}`}>
                          {activeFilter === f && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                        </div>
                        <input 
                          type="radio" 
                          name="status" 
                          className="hidden"
                          checked={activeFilter === f}
                          onChange={() => setActiveFilter(f)}
                        />
                        <span className={`text-sm ${activeFilter === f ? 'text-gray-900 dark:text-white font-bold' : 'text-gray-600 dark:text-gray-400'}`}>
                          {f}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="text-xs font-bold uppercase text-gray-400 mb-4 tracking-widest">Order Time</p>
                  <div className="space-y-3">
                    {TIME_FILTERS.map(f => (
                      <label key={f} className="flex items-center gap-3 cursor-pointer group">
                        <div className={`w-4 h-4 rounded-sm border transition-all flex items-center justify-center ${timeFilter === f ? 'bg-[#2874f0] border-[#2874f0]' : 'border-gray-300 dark:border-gray-600 group-hover:border-gray-400'}`}>
                          {timeFilter === f && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                        </div>
                        <input 
                          type="radio" 
                          name="time" 
                          className="hidden"
                          checked={timeFilter === f}
                          onChange={() => setTimeFilter(f)}
                        />
                        <span className={`text-sm ${timeFilter === f ? 'text-gray-900 dark:text-white font-bold' : 'text-gray-600 dark:text-gray-400'}`}>
                          {f}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Mobile Search & Filter (FOR ADMIN ONLY) */}
        {isAdmin && (
          <div className="lg:hidden p-4 bg-white dark:bg-[#141414] border-b border-gray-100 dark:border-white/5 flex gap-2">
             <div className="flex-1 relative">
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
               <input 
                 type="text" 
                 placeholder="Search your orders here"
                 value={searchQuery}
                 onChange={(e) => setSearchQuery(e.target.value)}
                 className="w-full pl-9 pr-4 py-2 bg-gray-100 dark:bg-white/5 rounded text-sm outline-none"
               />
             </div>
             <button className="px-3 py-2 bg-gray-100 dark:bg-white/5 rounded font-bold text-xs flex items-center gap-1">
               <Filter className="w-3 h-3" />
               Filters
             </button>
          </div>
        )}

        {/* Orders List */}
        <div className="flex-1 space-y-px sm:space-y-4">
          {filteredOrders.length === 0 ? (
            <div className="bg-white dark:bg-[#141414] rounded-sm p-12 text-center shadow-sm">
              <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-1">No orders found</h3>
              <p className="text-gray-500">Try adjusting your filters or search query</p>
            </div>
          ) : (
            filteredOrders.map((order) => (
              <div key={order.id}>
                <OrderCard order={order} onClick={() => setSelectedOrderId(order.id)} />
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

interface OrderCardProps {
  order: Order;
  onClick: () => void;
}

function OrderCard({ order, onClick }: OrderCardProps) {
  const getStatusDisplay = (status: string) => {
    switch (status) {
      case 'Delivered': return { label: 'Delivered', color: 'text-green-600', dot: 'bg-green-500' };
      case 'Cancelled': return { label: 'Cancelled', color: 'text-red-600', dot: 'bg-red-500' };
      case 'Pending': return { label: 'Pending', color: 'text-orange-500', dot: 'bg-orange-500' };
      case 'Preparing': return { label: 'Preparing', color: 'text-yellow-600 dark:text-yellow-500', dot: 'bg-yellow-500' };
      case 'Out for Delivery': return { label: 'Out for Delivery', color: 'text-blue-600', dot: 'bg-blue-500' };
      default: return { label: status, color: 'text-blue-600', dot: 'bg-blue-500' };
    }
  };

  const getStatusDateText = (status: string) => {
     switch(status) {
       case 'Delivered': return 'Delivered on';
       case 'Cancelled': return 'Cancelled on';
       default: return 'Arriving by';
     }
  };

  const getStatusDetailText = (status: string) => {
     switch(status) {
       case 'Delivered': return 'Your item has been delivered.';
       case 'Cancelled': return 'Your order has been cancelled.';
       case 'Pending': return 'Your order has been received.';
       case 'Preparing': return 'Your order is currently being prepared.';
       case 'Out for Delivery': return 'Your order is out for delivery.';
       default: return 'Your order is being processed.';
     }
  };

  const status = getStatusDisplay(order.status);

  return (
    <motion.div 
      onClick={onClick}
      className="bg-white dark:bg-[#141414] sm:rounded-sm border-b sm:border border-gray-100 dark:border-white/5 p-4 sm:p-6 transition-all hover:shadow-md cursor-pointer group"
    >
      <div className="flex gap-4 sm:gap-10">
        {/* Left: Product Image */}
        <div className="w-16 h-16 sm:w-20 sm:h-20 shrink-0 bg-gray-50 dark:bg-white/5 rounded-sm overflow-hidden flex items-center justify-center p-2 border border-gray-100 dark:border-white/10">
          {order.items[0]?.image ? (
            <img src={order.items[0].image} alt={order.items[0].name} className="w-full h-full object-contain" />
          ) : (
            <Package className="w-8 h-8 text-gray-300" />
          )}
        </div>

        {/* Middle: Info */}
        <div className="flex-1 min-w-0">
          <div className="flex flex-col lg:flex-row lg:justify-between gap-4">
             <div className="flex-1">
               <h3 className="text-sm sm:text-base font-bold text-gray-900 dark:text-white truncate group-hover:text-[#2874f0] transition-colors mb-1">
                 {order.items.map(i => i.name).join(', ')}
               </h3>
               <p className="text-[11px] text-gray-400 font-medium mb-3 tracking-wide">ID: #{order.id}</p>
               <div className="flex flex-wrap items-center gap-3 text-xs font-bold text-gray-500">
                  <span className="text-gray-900 dark:text-white">₹{order.total.toFixed(2)}</span>
                  <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
                  <span>{order.items.reduce((a, b) => a + b.quantity, 0)} Items</span>
               </div>
             </div>

             <div className="lg:w-64">
                <div className="flex items-center gap-2 mb-1.5">
                   <div className={`w-2.5 h-2.5 rounded-full ${status.dot} shadow-sm shadow-green-500/20`}></div>
                   <span className={`text-sm font-black ${status.color}`}>
                     {getStatusDateText(order.status)} {new Date(order.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}
                   </span>
                </div>
                <p className="text-[11px] text-gray-500 font-medium ml-4.5 tracking-tight">{getStatusDetailText(order.status)}</p>

                <div className="mt-4 flex items-center gap-1 text-[11px] font-black text-[#2874f0] hover:underline uppercase tracking-widest ml-4.5">
                   Rate & Review Product
                </div>
             </div>
          </div>
        </div>
        
        <div className="hidden sm:flex items-center">
          <ChevronRight className="w-5 h-5 text-gray-300 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </motion.div>
  );
}

function OrderDetailView({ order, onBack }: { order: Order, onBack: () => void }) {
  const [step, setStep] = useState(1);
  const [showInvoice, setShowInvoice] = useState(false);

  useEffect(() => {
    const statusMap: Record<string, number> = {
      'Pending': 1,
      'Preparing': 2,
      'Out for Delivery': 3,
      'Delivered': 4,
      'Cancelled': -1
    };
    setStep(statusMap[order.status] || 1);
  }, [order.status]);

  return (
    <div className="min-h-screen bg-[#f1f3f6] dark:bg-[#0a0a0a] pb-20">
      <div className="bg-white dark:bg-[#141414] sticky top-0 z-50 border-b border-gray-100 dark:border-white/5">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center gap-4">
           <button onClick={onBack} className="p-2 -ml-2 text-gray-700 dark:text-gray-300">
             <ArrowLeft className="w-6 h-6" />
           </button>
           <h2 className="text-lg font-bold">Order Details</h2>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-0 sm:px-4 py-0 sm:py-6 space-y-4">
        {/* Top Info Bar */}
        <div className="bg-white dark:bg-[#141414] p-4 sm:p-6 shadow-sm sm:rounded-sm flex flex-col md:flex-row justify-between gap-6">
           <div className="space-y-4">
              <div>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Delivery Address</p>
                <p className="text-sm font-bold">{order.address.name || 'User'}</p>
                <div className="text-xs text-gray-500 leading-relaxed mt-1">
                   {order.address.flat ? `${order.address.flat}, ` : ''}{order.address.address}
                   <br /> {order.address.city}, {order.address.zipCode}
                </div>
                <div className="mt-3 flex items-center gap-2">
                   <p className="text-[11px] font-black">Phone number</p>
                   <p className="text-xs text-gray-500">{order.address.phone || 'N/A'}</p>
                </div>
              </div>
           </div>

           <div className="space-y-3 md:w-80">
              <div>
                 <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Rewards Earned</p>
                 <div className="flex items-center gap-2 bg-yellow-50 dark:bg-yellow-500/5 p-3 rounded-lg border border-yellow-200/50">
                    <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                    <p className="text-xs font-bold text-yellow-800 dark:text-yellow-500">10 SuperCoins earned</p>
                 </div>
              </div>
              <button 
                onClick={() => setShowInvoice(true)}
                className="w-full py-2.5 bg-blue-50 dark:bg-blue-500/10 text-[#2874f0] border border-blue-200 dark:border-blue-500/20 rounded-sm text-xs font-bold flex items-center justify-center gap-2 hover:bg-blue-100 dark:hover:bg-blue-500/20 transition-colors">
                 <FileText className="w-4 h-4" />
                 Download Invoice
              </button>
              <button className="w-full py-2.5 border border-gray-200 dark:border-white/10 rounded-sm text-xs font-bold flex items-center justify-center gap-2 hover:bg-gray-50 dark:hover:bg-white/5">
                 <HelpCircle className="w-4 h-4" />
                 Need help?
              </button>
           </div>
        </div>

        {/* Tracker */}
        <div className="bg-white dark:bg-[#141414] p-6 sm:p-10 shadow-sm sm:rounded-sm overflow-x-auto">
           {step === -1 ? (
             <div className="text-center py-6">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-8 h-8 text-red-500" />
                </div>
                <h3 className="text-xl font-bold text-red-500 mb-2">Order Cancelled</h3>
                <p className="text-gray-500">This order has been cancelled.</p>
             </div>
           ) : (
             <div className="flex justify-between min-w-[500px] relative max-w-2xl mx-auto">
                <div className="absolute left-[10%] right-[10%] top-4 -translate-y-1/2 h-1.5 bg-gray-100 dark:bg-white/5 rounded-full"></div>
                <motion.div 
                  className="absolute left-[10%] top-4 -translate-y-1/2 h-1.5 bg-green-500 rounded-full origin-left"
                  initial={{ width: 0 }}
                  animate={{ width: `${((step - 1) / 3) * 80}%` }}
                ></motion.div>

                {[
                  { n: 1, l: 'Ordered', d: new Date(order.date).toLocaleDateString() },
                  { n: 2, l: 'Preparing', d: 'In Kitchen' },
                  { n: 3, l: 'Out for Delivery', d: 'On road' },
                  { n: 4, l: 'Delivered', d: 'Completed' }
                ].map(s => (
                  <div key={s.n} className="relative z-10 flex flex-col items-center gap-3 w-1/4">
                     <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all ${step >= s.n ? 'bg-green-500 border-green-500 text-white shadow-lg shadow-green-500/30' : 'bg-white dark:bg-[#141414] border-gray-200 dark:border-white/10 text-gray-300 dark:text-gray-600'}`}>
                        <CheckCircle2 className="w-4 h-4" />
                     </div>
                     <div className="text-center">
                       <p className={`text-[10px] font-black uppercase tracking-wider mb-0.5 ${step >= s.n ? 'text-gray-900 dark:text-white' : 'text-gray-400'}`}>{s.l}</p>
                       <p className="text-[10px] text-gray-400">{s.d}</p>
                     </div>
                  </div>
                ))}
             </div>
           )}
        </div>

        {/* Products List in Detailed View */}
        <div className="bg-white dark:bg-[#141414] shadow-sm sm:rounded-sm">
           <div className="p-4 border-b border-gray-100 dark:border-white/5 font-bold text-sm uppercase tracking-widest text-gray-400">Items ( {order.items.length} )</div>
           <div className="divide-y divide-gray-50 dark:divide-white/5">
              {order.items.map((item, idx) => (
                <div key={idx} className="p-4 flex gap-6 items-center">
                   <img src={item.image} alt={item.name} className="w-16 h-16 object-contain bg-gray-50 dark:bg-white/5 p-2 rounded border border-gray-100 dark:border-white/10" />
                   <div className="flex-1">
                      <h4 className="text-sm font-bold text-gray-900 dark:text-white mb-1">{item.name}</h4>
                      <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                      <p className="text-sm font-bold mt-2">₹{(item.price * item.quantity).toFixed(2)}</p>
                   </div>
                   <button className="text-[#2874f0] text-xs font-bold hover:underline">Buy it again</button>
                </div>
              ))}
           </div>
           <div className="p-6 bg-gray-50 dark:bg-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
              <div className="flex items-center gap-2">
                 <Package className="w-5 h-5 text-gray-500" />
                 <p className="text-xs font-bold text-gray-500">Total payable: <span className="text-gray-900 dark:text-white text-base ml-2">₹{order.total.toFixed(2)}</span></p>
              </div>
              <div className="flex gap-4">
                 <button className="px-6 py-2 bg-white dark:bg-black border border-gray-200 dark:border-white/10 rounded-sm text-xs font-bold shadow-sm">Cancel Order</button>
                 <button className="px-6 py-2 bg-[#2874f0] text-white rounded-sm text-xs font-bold shadow-sm">Change Address</button>
              </div>
           </div>
        </div>
      </div>
      <InvoiceModal show={showInvoice} onClose={() => setShowInvoice(false)} order={order} />
    </div>
  );
}
