import { X, Phone, ArrowLeft } from 'lucide-react';
import { useState } from 'react';
import { signInWithPopup } from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { toast } from 'react-hot-toast';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin?: (name: string) => void;
}

export default function ProfileModal({ isOpen, onClose, onLogin }: ProfileModalProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [authMode, setAuthMode] = useState<'default' | 'phone' | 'otp'>('default');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');

  if (!isOpen) return null;

  const handleGoogleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user && result.user.displayName) {
        onLogin?.(result.user.displayName);
      } else if (result.user && result.user.email) {
        onLogin?.(result.user.email.split('@')[0]);
      } else {
        onLogin?.('User');
      }
    } catch (error: any) {
      if (error.code === 'auth/unauthorized-domain' || error.message?.includes('unauthorized domain')) {
        toast.error('Preview error: Please add this URL to your Firebase Console Authorized Domains.', { duration: 6000 });
      } else if (error.code !== 'auth/popup-closed-by-user' && error.code !== 'auth/cancelled-popup-request') {
        toast.error(error.message || 'Google Sign-In failed');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose}></div>
      <div 
        className="relative bg-[#141414] rounded-3xl shadow-2xl shadow-red-500/10 w-full max-w-md overflow-hidden transform scale-100 transition-all border border-black/10 dark:border-white/10"
        style={{ animation: 'modalSlideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards' }}
      >
        <style>{`
          @keyframes modalSlideUp {
            from { opacity: 0; transform: translateY(40px) scale(0.95); }
            to { opacity: 1; transform: translateY(0) scale(1); }
          }
        `}</style>
        <div className="p-8">
          <button onClick={onClose} className="absolute top-4 right-4 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:text-white bg-black/5 dark:bg-white/5 hover:bg-black/5 dark:bg-white/10 transition-colors rounded-full p-2">
            <X className="w-5 h-5" />
          </button>
          
          {authMode === 'default' && (
            <>
              <div className="mb-8">
                <h2 className="text-3xl font-black tracking-tight text-gray-900 dark:text-white mb-2">
                  {isLogin ? 'Login' : 'Sign up'}
                </h2>
                <p className="text-gray-600 dark:text-gray-400 font-medium">
                  {isLogin ? 'Log in to Nexra Delivery to access your saved addresses and track orders.' : 'Create an account to start ordering delicious food to your door.'}
                </p>
              </div>
              
              <button 
                type="button"
                onClick={handleGoogleLogin}
                className="w-full flex items-center justify-center gap-3 bg-white dark:bg-black border border-gray-200 dark:border-white/10 text-gray-900 dark:text-white font-bold text-lg py-3.5 rounded-xl hover:bg-gray-50 dark:hover:bg-white/5 active:scale-[0.98] transition-all mb-3"
              >
                <svg viewBox="0 0 24 24" className="w-6 h-6">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                  <path d="M1 1h22v22H1z" fill="none"/>
                </svg>
                Continue with Google
              </button>

              <button 
                type="button"
                onClick={() => setAuthMode('phone')}
                className="w-full flex items-center justify-center gap-3 bg-white dark:bg-[#1a1a1a] border border-gray-200 dark:border-white/10 text-gray-900 dark:text-white font-bold text-lg py-3.5 rounded-xl hover:bg-gray-50 dark:hover:bg-white/5 active:scale-[0.98] transition-all mb-5"
              >
                <Phone className="w-5 h-5 text-gray-700 dark:text-gray-300" />
                Continue with Phone
              </button>
              
              <div className="flex items-center gap-4 mb-5">
                <div className="flex-1 h-px bg-gray-200 dark:bg-white/10"></div>
                <span className="text-gray-500 font-medium text-sm">OR</span>
                <div className="flex-1 h-px bg-gray-200 dark:bg-white/10"></div>
              </div>
              
              <form className="flex flex-col gap-5" onSubmit={(e) => { 
                e.preventDefault(); 
                const formData = new FormData(e.currentTarget);
                const rawName = formData.get('fullName') as string | null;
                const emailAdd = formData.get('emailAddress') as string;
                
                let finalName = rawName;
                if (!finalName && emailAdd) {
                   finalName = emailAdd.includes('@') ? emailAdd.split('@')[0] : 'User';
                }
                
                if (onLogin && finalName) {
                  onLogin(finalName);
                } else {
                  onClose(); 
                }
              }}>
                {!isLogin && (
                  <div>
                    <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1.5">Full Name</label>
                    <input name="fullName" type="text" required className="w-full px-4 py-3.5 rounded-xl border-2 border-black/10 dark:border-white/10 bg-[#0a0a0a] focus:border-[#E23744] focus:ring-4 focus:ring-red-500/20 outline-none transition-all font-medium text-gray-900 dark:text-white placeholder-gray-600" placeholder="e.g. John Doe" />
                  </div>
                )}
                <div>
                  <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1.5">Email Address</label>
                  <input name="emailAddress" type="email" required className="w-full px-4 py-3.5 rounded-xl border-2 border-black/10 dark:border-white/10 bg-[#0a0a0a] focus:border-[#E23744] focus:ring-4 focus:ring-red-500/20 outline-none transition-all font-medium text-gray-900 dark:text-white placeholder-gray-600" placeholder="Enter email" />
                </div>
                
                <button type="submit" className="w-full bg-gradient-to-r from-[#E23744] to-[#FF5E5E] text-gray-900 dark:text-white font-bold text-lg py-4 rounded-xl hover:shadow-[0_0_20px_rgba(226,55,68,0.4)] active:scale-[0.98] transition-all mb-2">
                  {isLogin ? 'Login with Email' : 'Create account'}
                </button>
              </form>
              
              <div className="mt-8 text-center text-[15px] font-medium text-gray-600 dark:text-gray-400">
                {isLogin ? "Don't have an account? " : "Already have an account? "}
                <button type="button" onClick={() => setIsLogin(!isLogin)} className="text-[#E23744] font-black hover:underline cursor-pointer">
                  {isLogin ? 'Sign up here' : 'Login here'}
                </button>
              </div>
            </>
          )}

          {authMode === 'phone' && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-300">
              <button onClick={() => setAuthMode('default')} className="flex items-center gap-2 text-gray-500 hover:text-gray-900 dark:hover:text-white mb-6 transition-colors font-medium">
                <ArrowLeft className="w-4 h-4" />
                Back
              </button>
              <h2 className="text-3xl font-black tracking-tight text-gray-900 dark:text-white mb-2">
                Enter your phone
              </h2>
              <p className="text-gray-600 dark:text-gray-400 font-medium mb-8">
                We will send you a 4-digit code to verify your account.
              </p>
              
              <form onSubmit={(e) => {
                e.preventDefault();
                if (phoneNumber.length >= 10) {
                  setAuthMode('otp');
                  toast.success('OTP sent to ' + phoneNumber);
                } else {
                  toast.error('Please enter a valid 10-digit number');
                }
              }} className="flex flex-col gap-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1.5">Phone Number</label>
                  <div className="flex gap-3">
                    <div className="flex items-center justify-center px-4 py-3.5 rounded-xl border-2 border-black/10 dark:border-white/10 bg-[#0a0a0a] text-gray-600 dark:text-gray-300 font-bold">
                      +91
                    </div>
                    <input 
                      type="tel" 
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
                      required 
                      className="flex-1 w-full px-4 py-3.5 rounded-xl border-2 border-black/10 dark:border-white/10 bg-[#0a0a0a] focus:border-[#E23744] focus:ring-4 focus:ring-red-500/20 outline-none transition-all font-medium text-gray-900 dark:text-white placeholder-gray-600 text-lg tracking-wider" 
                      placeholder="000 000 0000" 
                    />
                  </div>
                </div>
                <button type="submit" className="w-full bg-gradient-to-r from-[#E23744] to-[#FF5E5E] text-white font-bold text-lg py-4 rounded-xl hover:shadow-[0_0_20px_rgba(226,55,68,0.4)] active:scale-[0.98] transition-all">
                  Send OTP
                </button>
              </form>
            </div>
          )}

          {authMode === 'otp' && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-300">
              <button onClick={() => setAuthMode('phone')} className="flex items-center gap-2 text-gray-500 hover:text-gray-900 dark:hover:text-white mb-6 transition-colors font-medium">
                <ArrowLeft className="w-4 h-4" />
                Back
              </button>
              <h2 className="text-3xl font-black tracking-tight text-gray-900 dark:text-white mb-2">
                Verify OTP
              </h2>
              <p className="text-gray-600 dark:text-gray-400 font-medium mb-8">
                Enter the 4-digit code sent to +91 {phoneNumber}
              </p>
              
              <form onSubmit={(e) => {
                e.preventDefault();
                if (otp.length === 4) {
                  onLogin?.('User');
                  toast.success('Successfully logged in');
                } else {
                  toast.error('Please enter a 4-digit OTP');
                }
              }} className="flex flex-col gap-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1.5">One Time Password</label>
                  <input 
                    type="text" 
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 4))}
                    required 
                    className="w-full text-center tracking-[1em] px-4 py-4 rounded-xl border-2 border-black/10 dark:border-white/10 bg-[#0a0a0a] focus:border-[#E23744] focus:ring-4 focus:ring-red-500/20 outline-none transition-all font-bold text-gray-900 dark:text-white placeholder-gray-500 text-2xl" 
                    placeholder="••••" 
                  />
                </div>
                <button type="submit" className="w-full bg-gradient-to-r from-[#E23744] to-[#FF5E5E] text-white font-bold text-lg py-4 rounded-xl hover:shadow-[0_0_20px_rgba(226,55,68,0.4)] active:scale-[0.98] transition-all">
                  Verify & Login
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
