import { Search } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { motion } from 'motion/react';

interface HeroProps {
  setView: (view: any) => void;
  setSearchQuery: (q: string) => void;
}

export default function Hero({ setView, setSearchQuery }: HeroProps) {
  return (
    <div className="relative bg-gray-50 dark:bg-[#0a0a0a] pt-12 pb-16 sm:pt-20 sm:pb-24 overflow-hidden border-b border-black/5 dark:border-white/5 relative z-0 transition-colors duration-500">
      
      {/* Animated background food image */}
      <motion.div 
        className="absolute inset-0 z-[-20] opacity-15 dark:opacity-10"
        initial={{ scale: 1.1, x: 0, y: 0 }}
        animate={{ 
          scale: [1.1, 1.15, 1.1],
          x: [0, -10, 0],
          y: [0, -5, 0]
        }}
        transition={{ 
          duration: 25, 
          repeat: Infinity,
          ease: "linear"
        }}
      >
        <img 
          src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=2070&auto=format&fit=crop" 
          alt="Delicious food spread" 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
      </motion.div>

      {/* Decorative gradient glowing orb */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-[#E23744]/20 rounded-full blur-[120px] -z-10 pointer-events-none mix-blend-screen"></div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-[36px] sm:text-[50px] font-black text-gray-900 dark:text-white mb-6 leading-tight tracking-tight">
          Discover the best <span className="bg-gradient-to-r from-[#E23744] to-[#FF8C00] bg-clip-text text-transparent">food & drinks</span>
        </h1>
        <p className="text-base sm:text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-10 font-medium tracking-wide">
          Order food from favourite restaurants near you in seconds.
        </p>

        {/* Mobile Search Bar - Hidden on desktop since it's in the navbar */}
        <div className="md:hidden max-w-md mx-auto mb-10">
          <div className="relative w-full flex shadow-[0_8px_30px_rgba(226,55,68,0.15)] focus-within:shadow-[0_8px_30px_rgba(226,55,68,0.3)] transition-all border border-black/10 dark:border-white/10 rounded-2xl overflow-hidden bg-[#141414]">
            <div className="pl-4 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-500" />
            </div>
            <input
              id="mobile-hero-search"
              type="text"
              className="block w-full pl-3 pr-4 py-4 text-[15px] border-none outline-none bg-transparent placeholder-gray-500 text-gray-900 dark:text-white"
              placeholder="Restaurant, cuisine, or a dish..."
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  setSearchQuery((e.target as HTMLInputElement).value);
                  setView('search');
                }
              }}
            />
          </div>
        </div>

        {/* Quick Filters */}
        <div className="flex flex-wrap justify-center gap-3 max-w-3xl mx-auto animate-slamIn">
          {['Delivery', 'Dining Out', 'Nightlife', 'Pro Offers', 'Healthy', 'Pure Veg'].map((filter, index) => (
            <button
              key={filter}
              className={`px-6 py-2.5 rounded-full text-[14px] font-bold transition-all duration-300 hover:scale-105 active:scale-95 shadow-lg ${
                index === 0
                  ? 'bg-gradient-to-r from-[#E23744] to-[#FF5E5E] text-gray-900 dark:text-white shadow-red-500/20 border border-transparent'
                  : 'bg-[#141414] text-gray-700 dark:text-gray-300 border border-black/10 dark:border-white/10 hover:border-[#E23744] hover:text-[#E23744] hover:bg-[#1a1a1a]'
              }`}
              onClick={() => {
                setSearchQuery(filter);
                setView('search');
              }}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
