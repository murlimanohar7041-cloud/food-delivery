import { useState } from 'react';
import { Home, Compass, ShoppingBag, User, Heart } from 'lucide-react';
import { toast } from 'react-hot-toast';

interface BottomNavProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenProfile: () => void;
  onGoHome: () => void;
  onOpenWishlist: () => void;
  activeView: string;
}

export default function BottomNav({ cartCount, onOpenCart, onOpenProfile, onGoHome, onOpenWishlist, activeView }: BottomNavProps) {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-[#0a0a0a]/90 backdrop-blur-xl border-t border-black/10 dark:border-white/10 pb-safe z-50 shadow-[0_-10px_30px_rgba(0,0,0,0.5)]">
      <div className="flex justify-around items-center h-16">
        <button 
          onClick={() => {
            onGoHome();
          }}
          className={`flex flex-col items-center justify-center w-full h-full gap-1 transition-all duration-300 ${
            activeView === 'home' || activeView === 'menu' ? 'text-[#E23744]' : 'text-gray-500 hover:text-gray-700 dark:text-gray-300'
          }`}
        >
          <Home className={`w-6 h-6 transition-transform duration-300 ${activeView === 'home' ? 'scale-110 mb-0.5' : ''}`} />
          <span className="text-[10px] font-bold">Delivery</span>
        </button>

        <button 
          onClick={() => {
            onOpenWishlist();
          }}
          className={`flex flex-col items-center justify-center w-full h-full gap-1 transition-all duration-300 ${
            activeView === 'wishlist' ? 'text-[#E23744]' : 'text-gray-500 hover:text-gray-700 dark:text-gray-300'
          }`}
        >
          <Heart className={`w-6 h-6 transition-transform duration-300 ${activeView === 'wishlist' ? 'scale-110 mb-0.5 fill-current' : ''}`} />
          <span className="text-[10px] font-bold">Favorites</span>
        </button>

        <button 
          onClick={onOpenCart}
          className="flex flex-col items-center justify-center w-full h-full gap-1 text-gray-500 hover:text-[#E23744] transition-all duration-300 group"
        >
          <div className="relative">
            <ShoppingBag className="w-6 h-6 group-hover:scale-110 transition-transform duration-300" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-[#E23744] text-gray-900 dark:text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center shadow-[0_0_10px_rgba(226,55,68,0.5)] border border-[#0a0a0a]">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold">Cart</span>
        </button>
        
        <button 
          onClick={() => {
            onOpenProfile();
          }}
          className={`flex flex-col items-center justify-center w-full h-full gap-1 transition-all duration-300 text-gray-500 hover:text-[#E23744]`}
        >
          <User className="w-6 h-6 hover:scale-110 transition-transform duration-300" />
          <span className="text-[10px] font-bold">Profile</span>
        </button>
      </div>
    </div>
  );
}
