import { Star, Clock, Info } from 'lucide-react';
import { getFallbackImage } from '../utils/fallbackImage';
import { restaurants } from '../data';
import { toast } from 'react-hot-toast';

interface RestaurantGridProps {
  onSelectRestaurant: (restaurant: any) => void;
}

export default function RestaurantGrid({ onSelectRestaurant }: RestaurantGridProps) {
  return (
    <section className="py-10 bg-gray-50 dark:bg-[#0a0a0a] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-[24px] font-bold text-gray-900 dark:text-white mb-6">
          Nearby Restaurants
        </h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {restaurants.map((restaurant) => (
            <div 
              key={restaurant.id} 
              onClick={() => onSelectRestaurant(restaurant)}
              className="glass-card hover:-translate-y-1 bg-white dark:bg-[#141414] rounded-[16px] overflow-hidden border border-gray-200 dark:border-white/5 hover:border-[#E23744]/50 dark:hover:border-[#E23744]/50 hover:shadow-[0_12px_40px_rgba(226,55,68,0.15)] dark:hover:shadow-[0_12px_40px_rgba(226,55,68,0.25)] transition-all duration-500 group cursor-pointer"
            >
              {/* Image Container */}
              <div className="relative h-[200px] overflow-hidden bg-gray-100 dark:bg-[#1a1a1a]">
                <img 
                  src={restaurant.image} 
                  alt={restaurant.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-in-out"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    e.currentTarget.src = getFallbackImage(restaurant.id);
                    e.currentTarget.onerror = null;
                  }}
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 dark:from-[#141414] via-transparent to-transparent opacity-80"></div>
                
                {/* Promoted Badge */}
                {restaurant.promoted && (
                  <div className="absolute top-4 left-0 bg-gradient-to-r from-gray-900 to-gray-800 text-white text-[11px] font-bold px-3 py-1.5 rounded-r-md uppercase shadow-lg shadow-black/50 border border-white/10 border-l-0">
                    Promoted
                  </div>
                )}

                {/* Offer Badge */}
                {restaurant.offer && (
                  <div className="absolute top-4 left-0 bg-gradient-to-r from-[#256FEF] to-blue-400 text-white text-[12px] font-black px-3 py-1.5 rounded-r-md shadow-lg shadow-blue-500/30">
                    {restaurant.offer}
                  </div>
                )}
                
                {/* Delivery Time Pill */}
                <div className="absolute bottom-4 right-4 bg-white/90 dark:bg-black/60 backdrop-blur-md text-gray-900 dark:text-white text-[12px] font-bold px-3 py-1.5 rounded-full shadow-lg border border-white/20 dark:border-white/10 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-[#E23744]" />
                  {restaurant.deliveryTime}
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-[19px] font-bold text-gray-900 dark:text-white truncate pr-4 group-hover:text-[#E23744] transition-colors">
                    {restaurant.name}
                  </h3>
                  <div className="flex items-center gap-1 bg-[#24963F] text-white px-2 py-1 rounded-md text-[13px] font-bold shrink-0 shadow-[0_0_10px_rgba(36,150,63,0.3)]">
                    {restaurant.rating}
                    <Star className="w-3.5 h-3.5 fill-current" />
                  </div>
                </div>

                <div className="text-gray-600 dark:text-gray-400 text-[14px] mb-4 truncate font-medium">
                  {restaurant.cuisines.join(', ')}
                </div>
                
                <div className="flex justify-between items-center border-t border-black/10 dark:border-white/10 pt-4 text-[13px] text-gray-600 dark:text-gray-400 font-medium">
                  <p className="shrink-0 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-gray-500"></span>
                    {restaurant.priceForTwo}
                  </p>
              <button 
                onClick={(e) => {
                  e.stopPropagation(); 
                  toast('Restaurant details coming soon!', { icon: 'ℹ️' });
                }}
                className="shrink-0 flex items-center gap-1 group-hover:text-[#E23744] transition-colors"
              >
                <Info className="w-3.5 h-3.5" />
                Details
              </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
