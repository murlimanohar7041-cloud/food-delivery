import { X, Search, Heart, User, MapPin, ShoppingBag, LogOut, TrendingUp } from 'lucide-react';
import { toast } from 'react-hot-toast';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenProfile: () => void;
  userName: string | null;
  onLogout: () => void;
  setView: (view: any) => void;
  isAdmin?: boolean;
}

export default function MobileMenu({ isOpen, onClose, onOpenProfile, userName, onLogout, setView, isAdmin }: MobileMenuProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] md:hidden flex justify-end">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} style={{ animation: 'fadeIn 0.3s ease-out' }}></div>
      <style>{`
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideLeft { from { transform: translateX(100%); } to { transform: translateX(0); } }
      `}</style>
      <div 
        className="relative w-[80%] max-w-[320px] bg-[#0a0a0a] h-full shadow-[0_0_50px_rgba(0,0,0,0.5)] p-6 flex flex-col border-l border-black/10 dark:border-white/10"
        style={{ animation: 'slideLeft 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards' }}
      >
        <div className="flex justify-between items-center mb-8 pb-4 border-b border-black/10 dark:border-white/10">
          <span className="text-2xl font-black bg-gradient-to-r from-[#E23744] via-[#FF5E5E] to-[#FF8C00] bg-clip-text text-transparent">
            Nexra Delivery
          </span>
          <button onClick={onClose} className="p-2 bg-black/5 dark:bg-white/5 rounded-full hover:bg-black/5 dark:bg-white/10 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:text-white transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="flex flex-col gap-2">
          {userName ? (
            <div className="flex flex-col gap-2 mb-4 p-4 bg-[#141414] rounded-2xl border border-black/5 dark:border-white/5 shadow-inner">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-gradient-to-br from-[#E23744] to-[#FF5E5E] rounded-full flex items-center justify-center text-gray-900 dark:text-white font-bold text-lg shadow-[0_0_10px_rgba(226,55,68,0.4)]">
                  {userName.charAt(0).toUpperCase()}
                </div>
                <div>
                  <div className="font-bold text-gray-900 dark:text-white">{userName}</div>
                  <div className="text-sm text-[#E23744] font-medium">Foodie Member</div>
                </div>
              </div>
              <button 
                onClick={() => { onLogout(); onClose(); }}
                className="flex items-center gap-2 text-gray-500 hover:text-[#E23744] font-bold text-sm transition-colors mt-2"
              >
                <LogOut className="w-4 h-4" /> Logout
              </button>
            </div>
          ) : (
            <button 
              onClick={() => { onClose(); onOpenProfile(); }}
              className="flex items-center gap-4 text-gray-700 dark:text-gray-300 hover:text-[#E23744] hover:bg-[#141414] p-4 rounded-2xl font-bold text-xl transition-all group border border-transparent hover:border-black/5 dark:border-white/5"
            >
              <User className="w-6 h-6 group-hover:scale-110 transition-transform" /> Profile & Login
            </button>
          )}
          {isAdmin && (
            <button 
              onClick={() => { onClose(); setView('admin'); }}
              className="flex items-center gap-4 text-[#E23744] bg-[#E23744]/10 hover:bg-[#E23744]/20 p-4 rounded-2xl font-bold text-xl transition-all group border border-[#E23744]/20"
            >
              <TrendingUp className="w-6 h-6 group-hover:scale-110 transition-transform" /> Admin Dashboard
            </button>
          )}
          <button 
            onClick={() => { onClose(); setView('orders'); }}
            className="flex items-center gap-4 text-gray-700 dark:text-gray-300 hover:text-[#E23744] hover:bg-[#141414] p-4 rounded-2xl font-bold text-xl transition-all group border border-transparent hover:border-black/5 dark:border-white/5"
          >
            <ShoppingBag className="w-6 h-6 group-hover:scale-110 transition-transform" /> Your Orders
          </button>
          <button 
            onClick={() => { onClose(); setView('wishlist'); }}
            className="flex items-center gap-4 text-gray-700 dark:text-gray-300 hover:text-[#E23744] hover:bg-[#141414] p-4 rounded-2xl font-bold text-xl transition-all group border border-transparent hover:border-black/5 dark:border-white/5"
          >
            <Heart className="w-6 h-6 group-hover:scale-110 transition-transform" /> Favorites
          </button>
          <button 
            onClick={() => { onClose(); toast('Addresses feature coming soon!', { icon: '📍' }); }}
            className="flex items-center gap-4 text-gray-700 dark:text-gray-300 hover:text-[#E23744] hover:bg-[#141414] p-4 rounded-2xl font-bold text-xl transition-all group border border-transparent hover:border-black/5 dark:border-white/5"
          >
            <MapPin className="w-6 h-6 group-hover:scale-110 transition-transform" /> Addresses
          </button>
          <button 
            onClick={() => { onClose(); setView('search'); }}
            className="flex items-center gap-4 text-gray-700 dark:text-gray-300 hover:text-[#E23744] hover:bg-[#141414] p-4 rounded-2xl font-bold text-xl transition-all group border border-transparent hover:border-black/5 dark:border-white/5"
          >
            <Search className="w-6 h-6 group-hover:scale-110 transition-transform" /> Search Foods
          </button>
        </div>
        
        <div className="mt-auto pt-6 border-t border-black/10 dark:border-white/10 flex flex-col gap-4">
          <button 
            onClick={() => { toast('App links coming soon!', { icon: '📱' }); }}
            className="w-full bg-gradient-to-r from-[#E23744] to-[#FF5E5E] text-gray-900 dark:text-white font-bold py-4 rounded-2xl shadow-[0_0_20px_rgba(226,55,68,0.3)] hover:shadow-[0_0_25px_rgba(226,55,68,0.5)] active:scale-[0.98] transition-all text-lg"
          >
            Download the App
          </button>
          <button 
            onClick={() => { toast('Help & Support coming soon!', { icon: '🎧' }); }}
            className="w-full bg-[#141414] text-gray-700 dark:text-gray-300 font-bold py-4 rounded-2xl hover:bg-[#1a1a1a] hover:text-gray-900 dark:text-white transition-colors text-lg border border-black/5 dark:border-white/5"
          >
            Help & Support
          </button>
        </div>
      </div>
    </div>
  );
}
