import React, { useEffect, useState } from 'react';
import { ArrowLeft, RefreshCw, ExternalLink } from 'lucide-react';

interface SheetRow {
  orderId: string;
  firstName: string;
  lastName: string;
  email: string;
  address: string;
  city: string;
  orderDate: string;
  orderName: string;
  zipCode: string;
  otp: string;
  otpVerified: string | boolean;
  phoneNumber: string;
  status: string;
  productLink: string;
}

interface AdminDashboardProps {
  onBack: () => void;
  // Kept for backward compatibility with App.tsx if needed, though we don't use it now
  orders?: any[];
  onUpdateOrderStatus?: any;
}

const normalizeKey = (key: string) => key.toLowerCase().replace(/[^a-z0-9]/g, '');

const extractValue = (row: any, ...possibleNames: string[]) => {
  const normalizedRow: any = {};
  for (const k in row) {
    normalizedRow[normalizeKey(k)] = row[k];
  }
  for (const name of possibleNames) {
    const normName = normalizeKey(name);
    if (normalizedRow[normName] !== undefined && normalizedRow[normName] !== null) {
      return String(normalizedRow[normName]);
    }
  }
  return '';
};

export default function AdminDashboard({ onBack, orders = [], onUpdateOrderStatus }: AdminDashboardProps) {
  const [data, setData] = useState<SheetRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  const syncData = () => {
    setLoading(true);
    try {
      const formattedData: SheetRow[] = orders.map((order: any) => ({
        orderId: order.id,
        firstName: order.address.firstName || order.address.name || '',
        lastName: order.address.lastName || '',
        email: order.address.email || '',
        address: order.address.address || '',
        city: order.address.city || '',
        orderDate: new Date(order.date).toLocaleString('en-IN'),
        orderName: order.items.map((item: any) => `${item.quantity}x ${item.name}`).join(', '),
        zipCode: order.address.zipCode || '',
        otp: '',
        otpVerified: false,
        phoneNumber: order.address.phone || '',
        status: order.status || 'Pending',
        productLink: ''
      }));
      setData(formattedData.reverse());
      setLastUpdated(new Date());
    } catch (error) {
      console.error("Failed to sync orders data", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    syncData();
  }, [orders]);

  const getStatusColor = (status: string) => {
    const s = status.toLowerCase().trim();
    if (s.includes('pending')) return 'bg-orange-500/20 text-orange-500 border-orange-500/20';
    if (s.includes('preparing')) return 'bg-yellow-500/20 text-yellow-500 border-yellow-500/20';
    if (s.includes('out for delivery')) return 'bg-blue-500/20 text-blue-500 border-blue-500/20';
    if (s.includes('delivered')) return 'bg-green-500/20 text-green-500 border-green-500/20';
    if (s.includes('cancelled')) return 'bg-red-500/20 text-red-500 border-red-500/20';
    return 'bg-gray-500/20 text-gray-500 border-gray-500/20'; // fallback
  };

  const getOtpColor = (verified: string | boolean) => {
    const isVerified = String(verified).toLowerCase() === 'true' || String(verified).toLowerCase() === 'yes';
    return isVerified ? 'bg-green-500/20 text-green-500 border-green-500/20' : 'bg-red-500/20 text-red-500 border-red-500/20';
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#0a0a0a] pb-20 text-gray-900 dark:text-gray-100 transition-colors">
      <div className="bg-white dark:bg-[#141414] border-b border-gray-200 dark:border-white/10 sticky top-0 z-40 shadow-sm dark:shadow-[0_4px_20px_rgba(0,0,0,0.3)] transition-colors">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <button onClick={onBack} className="p-2 -ml-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:text-white hover:bg-gray-100 dark:hover:bg-white/10 rounded-full transition-colors">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-xl font-black text-gray-900 dark:text-white tracking-tight">Admin Dashboard</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs text-gray-500 dark:text-gray-400 hidden sm:block">
              Last updated: {lastUpdated.toLocaleTimeString()}
            </span>
            <button 
              onClick={syncData} 
              className="flex items-center gap-2 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors border border-black/5 dark:border-white/10"
              disabled={loading}
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Refresh</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Orders Table */}
        <div className="bg-white dark:bg-[#141414] rounded-2xl border border-gray-200 dark:border-white/5 shadow-sm dark:shadow-xl overflow-hidden transition-colors">
          <div className="p-5 border-b border-gray-200 dark:border-white/5 flex justify-between items-center bg-gray-50/50 dark:bg-black/20">
            <div>
              <h3 className="font-bold text-lg text-gray-900 dark:text-white">Live Orders Database</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Synced securely with App</p>
            </div>
            <div className="bg-red-500/10 text-red-600 dark:text-[#E23744] text-xs font-bold px-3 py-1.5 rounded-md border border-red-500/20">
              Live Connection
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm whitespace-nowrap">
              <thead className="bg-gray-50 dark:bg-[#0a0a0a] text-gray-500 dark:text-gray-400 border-b border-gray-200 dark:border-white/5">
                <tr>
                  <th className="px-6 py-4 font-bold tracking-wider uppercase text-xs">Order ID</th>
                  <th className="px-6 py-4 font-bold tracking-wider uppercase text-xs">Date</th>
                  <th className="px-6 py-4 font-bold tracking-wider uppercase text-xs">Customer</th>
                  <th className="px-6 py-4 font-bold tracking-wider uppercase text-xs">Contact</th>
                  <th className="px-6 py-4 font-bold tracking-wider uppercase text-xs">Address</th>
                  <th className="px-6 py-4 font-bold tracking-wider uppercase text-xs">Order Details</th>
                  <th className="px-6 py-4 font-bold tracking-wider uppercase text-xs">Status</th>
                  <th className="px-6 py-4 font-bold tracking-wider uppercase text-xs">OTP Details</th>
                  <th className="px-6 py-4 font-bold tracking-wider uppercase text-xs">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-white/5">
                {loading && data.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="px-6 py-12 text-center">
                      <div className="flex flex-col items-center justify-center">
                        <RefreshCw className="w-8 h-8 text-gray-400 animate-spin mb-4" />
                        <p className="text-gray-500 font-medium">Fetching secure data...</p>
                      </div>
                    </td>
                  </tr>
                ) : data.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="px-6 py-12 text-center text-gray-500">
                      No records found in the database.
                    </td>
                  </tr>
                ) : (
                  data.map((row, idx) => (
                    <tr key={idx} className="hover:bg-gray-50 dark:hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4 font-bold text-gray-900 dark:text-gray-300">
                        {row.orderId || '-'}
                      </td>
                      <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                        {row.orderDate ? new Date(row.orderDate).toLocaleDateString() : '-'}
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-bold text-gray-900 dark:text-gray-300">{row.firstName} {row.lastName}</div>
                        <div className="text-xs text-gray-500">{row.email}</div>
                      </td>
                      <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                        {row.phoneNumber || '-'}
                      </td>
                      <td className="px-6 py-4 text-gray-600 dark:text-gray-400">
                        <div className="max-w-[200px] truncate" title={row.address}>{row.address}</div>
                        <div className="text-xs">{row.city} {row.zipCode}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-gray-900 dark:text-gray-300 max-w-[200px] truncate" title={row.orderName}>
                          {row.orderName || '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <select 
                          className={`px-3 py-1 rounded-full text-xs font-bold border outline-none cursor-pointer appearance-none ${getStatusColor(row.status)}`}
                          value={row.status || 'Pending'}
                          onChange={(e) => onUpdateOrderStatus && onUpdateOrderStatus(row.orderId, e.target.value)}
                        >
                          <option className="bg-white text-gray-900" value="Pending">Pending</option>
                          <option className="bg-white text-gray-900" value="Preparing">Preparing</option>
                          <option className="bg-white text-gray-900" value="Out for Delivery">Out for Delivery</option>
                          <option className="bg-white text-gray-900" value="Delivered">Delivered</option>
                          <option className="bg-white text-gray-900" value="Cancelled">Cancelled</option>
                        </select>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-white/5 px-2 py-0.5 rounded text-xs">{row.otp || '---'}</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getOtpColor(row.otpVerified)}`}>
                            {String(row.otpVerified).toLowerCase() === 'true' || String(row.otpVerified).toLowerCase() === 'yes' ? 'True' : 'False'}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {row.productLink ? (
                          <a 
                            href={row.productLink} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 bg-[#E23744] hover:bg-red-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-colors shadow-sm"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            View Product
                          </a>
                        ) : (
                          <span className="text-gray-400 text-xs italic">No Link</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
}
