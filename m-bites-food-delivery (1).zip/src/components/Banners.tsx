import { Percent, Truck } from 'lucide-react';

interface BannersProps {
  setView: (view: any) => void;
  setSearchQuery: (q: string) => void;
}

export default function Banners({ setView, setSearchQuery }: BannersProps) {
  return (
    <section className="py-8 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Banner 1: 50% OFF */}
          <div 
            onClick={() => setView('offers')}
            className="bg-[#141414] rounded-[16px] p-6 sm:p-8 text-gray-900 dark:text-white flex items-center justify-between border border-black/5 dark:border-white/5 hover:border-[#E23744]/50 hover:shadow-[0_8px_30px_rgba(226,55,68,0.15)] transition-all duration-300 cursor-pointer overflow-hidden relative group"
          >
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-2 text-[#E23744]">
                <Percent className="w-5 h-5 sm:w-6 sm:h-6" />
                <span className="font-bold tracking-wider uppercase text-[11px] sm:text-[12px]">Mega Sale</span>
              </div>
              <h3 className="text-[28px] sm:text-[32px] font-bold mb-1">50% OFF</h3>
              <p className="text-gray-600 dark:text-gray-400 font-medium text-[14px] mb-4">on your first order</p>
              <button 
                onClick={(e) => { e.stopPropagation(); setView('offers'); }}
                className="bg-gradient-to-r from-[#E23744] to-[#FF5E5E] text-gray-900 dark:text-white px-5 py-2 rounded-lg font-bold text-[14px] hover:shadow-[0_0_15px_rgba(226,55,68,0.4)] transition-all active:scale-95"
              >
                Order Now
              </button>
            </div>
            {/* Dark gradient overlay for better text readability */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#141414] via-[#141414]/90 to-transparent z-[5]"></div>
            <img 
              src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=400&fit=crop" 
              alt="Burger" 
              className="absolute right-0 top-0 h-full w-48 sm:w-64 object-cover opacity-60 mix-blend-lighten group-hover:scale-110 transition-transform duration-700" 
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Banner 2: Free Delivery */}
          <div 
            onClick={() => {
              setSearchQuery('Free Delivery');
              setView('search');
            }}
            className="bg-[#141414] rounded-[16px] p-6 sm:p-8 text-gray-900 dark:text-white flex items-center justify-between border border-black/5 dark:border-white/5 hover:border-[#24963F]/50 hover:shadow-[0_8px_30px_rgba(36,150,63,0.15)] transition-all duration-300 cursor-pointer overflow-hidden relative group"
          >
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-2 text-[#24963F]">
                <Truck className="w-5 h-5 sm:w-6 sm:h-6" />
                <span className="font-bold tracking-wider uppercase text-[11px] sm:text-[12px]">Special Offer</span>
              </div>
              <h3 className="text-[28px] sm:text-[32px] font-bold mb-1">Free Delivery</h3>
              <p className="text-gray-600 dark:text-gray-400 font-medium text-[14px] mb-4">on orders above ₹499</p>
              <button 
                onClick={(e) => { e.stopPropagation(); setSearchQuery('Free Delivery'); setView('search'); }}
                className="bg-gradient-to-r from-[#24963F] to-[#2ebd4f] text-gray-900 dark:text-white px-5 py-2 rounded-lg font-bold text-[14px] hover:shadow-[0_0_15px_rgba(36,150,63,0.4)] transition-all active:scale-95"
              >
                Explore
              </button>
            </div>
            {/* Dark gradient overlay for better text readability */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#141414] via-[#141414]/90 to-transparent z-[5]"></div>
            <img 
              src="https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=400&h=400&fit=crop" 
              alt="Pizza" 
              className="absolute right-0 top-0 h-full w-48 sm:w-64 object-cover opacity-60 mix-blend-lighten group-hover:scale-110 transition-transform duration-700" 
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
