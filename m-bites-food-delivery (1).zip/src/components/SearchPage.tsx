import React, { useState } from 'react';
import { getFallbackImage } from '../utils/fallbackImage';
import { ArrowLeft, Search, Filter, SortDesc, ShoppingCart, Heart, Star, Plus } from 'lucide-react';
import { products } from '../products';
import { toast } from 'react-hot-toast';
import { motion, AnimatePresence } from 'motion/react';

interface SearchPageProps {
  onBack: () => void;
  onAddToCart: (item: any) => void;
  onBuyNow?: (item: any) => void;
  onProductClick?: (item: any) => void;
  initialQuery?: string;
  wishlistIds?: number[];
  onToggleWishlist?: (id: number) => void;
}

export default function SearchPage({ onBack, onAddToCart, onBuyNow, onProductClick, initialQuery = '', wishlistIds = [], onToggleWishlist }: SearchPageProps) {
  const [query, setQuery] = useState(initialQuery);
  const [minPrice, setMinPrice] = useState('100');
  const [maxPrice, setMaxPrice] = useState('600');
  const [category, setCategory] = useState('All');
  
  const allCategories = ['All', 'Pizza', 'Burgers', 'Healthy', 'Drinks', 'Desserts', 'Sushi', 'Coffee'];

  const filteredItems = products.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(query.toLowerCase()) || 
                          item.category.toLowerCase().includes(query.toLowerCase());
    
    const priceDisplay = item.price;
    const matchPrice = priceDisplay >= Number(minPrice || 0) && priceDisplay <= Number(maxPrice || 10000);
    const matchCategory = category === 'All' ? true : item.category === category; 

    return matchesSearch && matchPrice && matchCategory;
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#0a0a0a] pb-20 text-gray-900 dark:text-gray-100 transition-colors">
      <div className="bg-white dark:bg-[#141414] border-b border-gray-200 dark:border-white/10 sticky top-0 z-40 shadow-sm dark:shadow-[0_4px_20px_rgba(0,0,0,0.3)] transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col gap-4">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="p-2 -ml-2 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-white/10 rounded-full transition-colors">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input 
                autoFocus
                type="text" 
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search food, restaurants..." 
                className="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-200 dark:border-white/10 bg-gray-50 dark:bg-[#0a0a0a] text-gray-900 dark:text-white focus:outline-none focus:border-[#E23744] focus:ring-1 focus:ring-[#E23744] transition-all shadow-inner"
              />
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between text-sm">
            <div className="flex flex-wrap items-center gap-2">
              <Filter className="w-4 h-4 text-gray-500 dark:text-gray-400" />
              <span className="font-bold text-gray-700 dark:text-gray-300">Category:</span>
              <div className="flex overflow-x-auto hide-scrollbar gap-2 max-w-[250px] sm:max-w-md">
                {allCategories.map(cat => (
                  <button 
                    key={cat}
                    onClick={() => setCategory(cat)}
                    className={`px-3 py-1.5 rounded-full border whitespace-nowrap transition-colors ${category === cat ? 'bg-[#E23744] border-transparent text-white' : 'bg-white dark:bg-transparent border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:border-gray-300 dark:hover:border-white/20'}`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="flex items-center gap-2 bg-gray-100 dark:bg-[#1a1a1a] p-2 rounded-lg border border-gray-200 dark:border-white/10 shrink-0 shadow-sm">
              <SortDesc className="w-4 h-4 text-gray-500 dark:text-gray-400" />
              <span className="font-bold text-gray-700 dark:text-gray-300 px-1">Price Range:</span>
              <input 
                type="number" 
                value={minPrice} 
                onChange={e => setMinPrice(e.target.value)}
                className="w-16 bg-white dark:bg-[#0a0a0a] border border-gray-200 dark:border-white/10 rounded px-2 py-1 text-gray-900 dark:text-white text-center focus:outline-none focus:border-red-500" 
              />
              <span className="text-gray-500">-</span>
              <input 
                type="number" 
                value={maxPrice} 
                onChange={e => setMaxPrice(e.target.value)}
                className="w-16 bg-white dark:bg-[#0a0a0a] border border-gray-200 dark:border-white/10 rounded px-2 py-1 text-gray-900 dark:text-white text-center focus:outline-none focus:border-red-500" 
              />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h2 className="text-lg font-bold text-gray-700 dark:text-gray-300 mb-6 flex items-center gap-2">
          Results for "{query || category}" <span className="text-gray-500 text-sm">({filteredItems.length} found)</span>
        </h2>

        {filteredItems.length === 0 ? (
          <div className="text-center py-20 text-gray-500">
            <Search className="w-16 h-16 mx-auto mb-4 opacity-20" />
            <p>No items found matching your filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredItems.map(item => {
              const isWishlisted = wishlistIds.includes(item.id);
              const originalPrice = item.disc ? Math.round(item.price / (1 - item.disc / 100)) : item.price;
              
              return (
              <div 
                key={item.id} 
                className="bg-white dark:bg-[#141414] border border-gray-200 dark:border-white/5 p-4 rounded-xl flex gap-4 hover:border-[#E23744]/50 hover:shadow-md transition-all group relative cursor-pointer"
                onClick={() => onProductClick?.(item)}
              >
                <div className="relative w-24 h-24 rounded-lg overflow-hidden shrink-0 border border-gray-100 dark:border-white/5 bg-gray-50 dark:bg-[#1a1a1a]">
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                    onError={(e) => {
                      e.currentTarget.src = getFallbackImage(item.id);
                      e.currentTarget.onerror = null;
                    }}
                  />
                  {item.isVeg !== undefined && (
                    <div className="absolute bottom-1 right-1 bg-white/90 dark:bg-black/80 backdrop-blur-md p-1 rounded border border-gray-200 dark:border-white/10 scale-75">
                      <div className={`w-3 h-3 border rounded-sm flex items-center justify-center ${item.isVeg ? 'border-green-500' : 'border-red-500'}`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${item.isVeg ? 'bg-green-500' : 'bg-red-500'}`}></div>
                      </div>
                    </div>
                  )}
                </div>
                <div className="flex flex-col flex-1">
                  <div>
                    <h3 className="font-bold text-gray-900 dark:text-white text-base leading-tight mb-1 group-hover:text-[#E23744] transition-colors pr-8 line-clamp-2">{item.name}</h3>
                    
                    <div className="flex items-center gap-1.5 mb-1.5 text-[10px]">
                      <div className="flex items-center gap-0.5 bg-green-600 text-white px-1.5 py-0.5 rounded font-bold shadow-sm">
                        {item.rating || 4.5} <Star className="w-2.5 h-2.5 fill-current" />
                      </div>
                    </div>

                    <div className="flex items-baseline gap-1.5 mt-1">
                      <p className="text-gray-900 dark:text-white font-black text-lg">₹{item.price}</p>
                      {item.disc && (
                        <>
                          <p className="text-xs text-gray-400 line-through">₹{originalPrice}</p>
                          <p className="text-[10px] font-black text-[#E23744] tracking-wide">{item.disc}% OFF</p>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-auto pt-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onBuyNow?.(item);
                      }}
                      className="flex-1 py-2 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-500 hover:to-yellow-600 text-black font-black text-xs rounded-lg active:scale-95 transition-all shadow-[0_4px_14px_rgba(251,191,36,0.3)] uppercase text-center"
                    >
                      Buy Now
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        onAddToCart(item);
                      }}
                      className="p-2 w-10 h-10 flex items-center justify-center bg-gray-100 dark:bg-[#1a1a1a] text-gray-900 dark:text-white hover:bg-[#E23744] hover:text-white dark:hover:bg-[#E23744] font-bold rounded-lg border border-transparent transition-all active:scale-95 shrink-0 group/add"
                    >
                      <ShoppingCart className="w-4 h-4 group-hover/add:hidden" />
                      <Plus className="w-5 h-5 hidden group-hover/add:block" />
                    </button>
                  </div>
                </div>
                {onToggleWishlist && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleWishlist(item.id);
                    }}
                    className="absolute top-4 right-4 z-10 p-2 bg-white/90 dark:bg-black/50 backdrop-blur-md rounded-full shadow-sm hover:scale-110 active:scale-90 transition-all duration-300 border border-transparent dark:border-white/10 hover:border-[#E23744]/30"
                  >
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={isWishlisted ? 'filled' : 'outline'}
                        initial={{ scale: 0.5, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.5, opacity: 0 }}
                        transition={{ duration: 0.15 }}
                      >
                        <Heart 
                          className={`w-4 h-4 ${isWishlisted ? 'fill-[#E23744] text-[#E23744]' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'}`} 
                        />
                      </motion.div>
                    </AnimatePresence>
                  </button>
                )}
              </div>
            )})}
          </div>
        )}
      </div>
    </div>
  );
}
