import { useState, useEffect } from 'react';
import { getFallbackImage } from '../utils/fallbackImage';
import { Star, ShoppingCart, Plus, Heart } from 'lucide-react';
import { getMixedProducts } from '../products';
import { motion, AnimatePresence } from 'motion/react';

interface ProductGridProps {
  onAddToCart: (item: any) => void;
  onBuyNow?: (item: any) => void;
  onProductClick?: (item: any) => void;
  wishlistIds?: number[];
  onToggleWishlist?: (id: number) => void;
}

export default function ProductGrid({ onAddToCart, onBuyNow, onProductClick, wishlistIds = [], onToggleWishlist }: ProductGridProps) {
  const [products] = useState<any[]>(() => getMixedProducts());

  return (
    <section className="py-10 bg-gray-50 dark:bg-[#0a0a0a] min-h-screen transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-[28px] font-black text-gray-900 dark:text-white tracking-tight">
            Explore Menu
          </h2>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 sm:gap-6">
          {products.map((product, index) => {
            const isWishlisted = wishlistIds.includes(product.id);
            return (
            <motion.div 
              key={`${product.id}-${index}`}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "50px" }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              onClick={() => onProductClick?.(product)}
              className="bg-white dark:bg-[#141414] rounded-xl sm:rounded-2xl overflow-hidden border border-gray-200 dark:border-white/5 hover:border-[#E23744]/30 dark:hover:border-[#E23744]/50 shadow-sm hover:shadow-[0_8px_30px_rgba(226,55,68,0.12)] dark:hover:shadow-[0_8px_30px_rgba(226,55,68,0.2)] transition-all duration-300 group flex flex-col relative cursor-pointer"
            >
              {/* Wishlist Button */}
              {onToggleWishlist && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleWishlist(product.id);
                  }}
                  className="absolute top-2 right-2 sm:top-3 sm:right-3 z-10 p-1.5 sm:p-2 bg-white/90 dark:bg-black/80 backdrop-blur-md rounded-full shadow-sm hover:scale-110 active:scale-90 transition-all duration-300 border border-transparent dark:border-white/10 group-hover:border-[#E23744]/30"
                >
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={isWishlisted ? 'filled' : 'outline'}
                      initial={{ scale: 0.5, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.5, opacity: 0 }}
                      transition={{ duration: 0.15 }}
                    >
                      <Heart 
                        className={`w-3.5 h-3.5 sm:w-4 h-4 ${isWishlisted ? 'fill-[#E23744] text-[#E23744]' : 'text-gray-600 dark:text-gray-300'}`} 
                      />
                    </motion.div>
                  </AnimatePresence>
                </button>
              )}

              {/* Image Container */}
              <div className="relative h-[110px] sm:h-[180px] overflow-hidden bg-gray-100 dark:bg-[#1a1a1a]">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-in-out"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                  onError={(e) => {
                    e.currentTarget.src = getFallbackImage(product.id);
                    e.currentTarget.onerror = null;
                  }}
                />
                
                {/* Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                {/* Veg/Non-Veg Badge */}
                <div className="absolute top-2 right-2 sm:top-3 sm:right-3 bg-white/90 dark:bg-black/80 backdrop-blur-md p-1 sm:p-1.5 rounded-lg border border-gray-200 dark:border-white/10 scale-75 sm:scale-100">
                  <div className={`w-3.5 h-3.5 border rounded-sm flex items-center justify-center ${product.isVeg ? 'border-green-500' : 'border-red-500'}`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${product.isVeg ? 'bg-green-500' : 'bg-red-500'}`}></div>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-3 sm:p-4 flex flex-col flex-1">
                <div className="mb-0.5 sm:mb-1 text-[9px] sm:text-[11px] font-bold tracking-wider uppercase text-gray-500 dark:text-gray-400">
                  {product.category}
                </div>
                
                <h3 className="text-[13px] sm:text-[16px] font-bold text-gray-900 dark:text-white mb-1.5 line-clamp-2 leading-snug group-hover:text-[#E23744] transition-colors h-[2.8em] sm:h-auto">
                  {product.name}
                </h3>

                {/* Rating & Percentage */}
                <div className="flex items-center gap-1.5 mb-1.5 text-[10px] sm:text-xs">
                  <div className="flex items-center gap-0.5 bg-green-600 text-white px-1.5 py-0.5 rounded font-bold shadow-sm">
                    {product.rating} <Star className="w-2.5 h-2.5 sm:w-3 sm:h-3 fill-current" />
                  </div>
                </div>

                {/* Price Details */}
                <div className="flex items-center gap-1.5 sm:gap-2 mt-auto">
                  <span className="text-[15px] sm:text-[18px] font-black text-gray-900 dark:text-white">
                    ₹{product.price}
                  </span>
                  {product.disc && (
                    <>
                      <span className="text-[11px] sm:text-[13px] text-gray-400 line-through">
                        ₹{Math.round(product.price / (1 - product.disc / 100))}
                      </span>
                      <span className="text-[10px] sm:text-[11px] font-black text-[#E23744] dark:text-[#ff5c6a] tracking-wide">
                        {product.disc}% OFF
                      </span>
                    </>
                  )}
                </div>
                
                <div className="mt-3 sm:mt-4 pt-2 sm:pt-3 border-t border-gray-100 dark:border-white/5 flex items-center justify-between gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onBuyNow?.(product);
                    }}
                    className="flex-1 py-1.5 sm:py-2 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-500 hover:to-yellow-600 text-black font-black text-[11px] sm:text-[13px] rounded-lg transition-all active:scale-95 shadow-[0_4px_14px_rgba(251,191,36,0.3)] uppercase flex items-center justify-center gap-1"
                  >
                    Buy Now
                  </button>

                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddToCart(product);
                    }}
                    className="w-8 h-8 sm:w-10 sm:h-10 shrink-0 rounded-lg sm:rounded-xl bg-gray-100 dark:bg-white/5 text-gray-900 dark:text-white flex items-center justify-center hover:bg-gray-200 dark:hover:bg-white/10 transition-all duration-300 shadow-sm active:scale-95 group/btn"
                    title="Add to Cart"
                  >
                    <ShoppingCart className="w-3.5 h-3.5 sm:w-4 sm:h-4 group-hover/btn:hidden" />
                    <Plus className="w-4 h-4 sm:w-5 sm:h-5 hidden group-hover/btn:block" />
                  </button>
                </div>
              </div>
            </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
