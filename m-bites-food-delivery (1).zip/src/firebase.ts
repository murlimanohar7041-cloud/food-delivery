import { initializeApp, getApps } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase only once
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Validate Connection to Firestore globally as per guidelines
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('auth/network-request-failed')) {
        console.warn("Firebase Auth network request failed (often a transient preview iframe issue).");
      } else if (error.message.includes('the client is offline')) {
        console.error("Please check your Firebase configuration.");
      } else {
        console.error("Firestore test connection warning:", error.message);
      }
    }
  }
}

// Small delay to allow Firebase Auth to initialize before testing connection
setTimeout(testConnection, 1000);

