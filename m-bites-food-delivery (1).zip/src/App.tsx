/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, Suspense } from 'react';
import { Toaster, toast } from 'react-hot-toast';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import { auth, db } from './firebase';
import { collection, doc, setDoc, updateDoc, onSnapshot, query, where, getDocs, orderBy } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from './lib/firestore-errors';
import { AnimatePresence } from 'motion/react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Banners from './components/Banners';
import Categories from './components/Categories';
import ProductGrid from './components/ProductGrid';
import BottomNav from './components/BottomNav';
import MenuPage from './components/MenuPage';
import CartPanel from './components/CartPanel';
import CheckoutPage from './components/CheckoutPage';
import SuccessScreen from './components/SuccessScreen';
import OffersPage from './components/OffersPage';
import SkeletonGrid from './components/SkeletonGrid';

import OrdersPage, { Order } from './components/OrdersPage';
import AdminDashboard from './components/AdminDashboard';
import SearchPage from './components/SearchPage';
import WishlistPage from './components/WishlistPage';
import ProfileModal from './components/ProfileModal';
import MobileMenu from './components/MobileMenu';
import ProductModal from './components/ProductModal';
import Footer from './components/Footer';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  isVeg: boolean;
  image?: string;
}

type ViewState = 'home' | 'menu' | 'checkout' | 'success' | 'offers' | 'search' | 'orders' | 'admin' | 'wishlist';

export default function App() {
  const [view, setView] = useState<ViewState>('home');
  const [selectedRestaurant, setSelectedRestaurant] = useState<any>(null);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [userName, setUserName] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  
  // Track Firebase Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      if (user) {
        setUserName(user.displayName || (user.email ? user.email.split('@')[0] : 'User'));
        setUserEmail(user.email);
      } else {
        setUserEmail(null);
        setUserName(null);
        setOrders([]);
      }
    });
    return () => unsubscribe();
  }, []);

  // Fetch / Sync Orders from Firestore
  useEffect(() => {
    if (!currentUser) return;
    
    let q;
    if (currentUser.email === 'murlimanohar7041@gmail.com') {
      // Admin sees all orders
      q = query(collection(db, 'orders'));
    } else {
      q = query(collection(db, 'orders'), where('userId', '==', currentUser.uid));
    }

    const unSub = onSnapshot(q, (snapshot) => {
      const fetchedOrders: Order[] = [];
      snapshot.forEach((docSnap) => {
        fetchedOrders.push({ id: docSnap.id, ...docSnap.data() } as Order);
      });
      // Sort orders descending
      fetchedOrders.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      setOrders(fetchedOrders);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'orders');
    });

    return () => unSub();
  }, [currentUser]);

  // Advanced Features State
  const [currentOrder, setCurrentOrder] = useState<Order | undefined>(undefined);
  const [orders, setOrders] = useState<Order[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    // Force dark mode on mount as default
    document.documentElement.classList.add('dark');
  }, []);

  const handleNavChange = (newView: ViewState, restaurant: any = null) => {
    setIsTransitioning(true);
    setTimeout(() => {
      if (restaurant !== null) {
        setSelectedRestaurant(restaurant);
      }
      setView(newView);
      setIsTransitioning(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 400);
  };

  // Handle hardware/browser back buttons intuitively
  useEffect(() => {
    // Whenever a deep state is entered, push a state so the back button actually triggers popstate instead of exiting the app.
    // We only push if it's considered a "deep" view.
    if (view !== 'home' || isCartOpen || isProfileOpen || isMobileMenuOpen) {
      window.history.pushState({ modalObject: true }, '');
    }
  }, [view, isCartOpen, isProfileOpen, isMobileMenuOpen]);

  useEffect(() => {
    const handlePopState = (e: PopStateEvent) => {
      // Prioritize closing overlays first, then page views
      if (isMobileMenuOpen) {
        setIsMobileMenuOpen(false);
      } else if (isCartOpen) {
        setIsCartOpen(false);
      } else if (isProfileOpen) {
        setIsProfileOpen(false);
      } else if (view !== 'home') {
        if (view === 'checkout') handleNavChange(selectedRestaurant ? 'menu' : 'home');
        else if (view === 'success') handleNavChange('home');
        else handleNavChange('home'); 
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [view, isCartOpen, isProfileOpen, isMobileMenuOpen, selectedRestaurant]);

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleLogin = (name: string) => {
    setUserName(name);
    setIsProfileOpen(false);
    toast.success(`Welcome back, ${name}!`);
  };

  const handleAddToCart = (item: any) => {
    setCartItems(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { id: item.id, name: item.name, price: item.price, quantity: 1, isVeg: item.isVeg, image: item.image || '' }];
    });
    if (cartItems.length === 0) {
      setIsCartOpen(true);
    }
  };

  const handleBuyNow = (item: any) => {
    setCartItems(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { id: item.id, name: item.name, price: item.price, quantity: 1, isVeg: item.isVeg, image: item.image || '' }];
    });
    handleNavChange('checkout');
  };

  const handleUpdateQuantity = (id: number, delta: number) => {
    setCartItems(prev => {
      return prev.map(item => {
        if (item.id === id) {
          return { ...item, quantity: Math.max(0, item.quantity + delta) };
        }
        return item;
      }).filter(item => item.quantity > 0);
    });
  };

  const handleCheckout = () => {
    setIsCartOpen(false);
    handleNavChange('checkout');
  };

  const handlePlaceOrder = async (orderData: Omit<Order, 'id' | 'date' | 'status'>) => {
    if (!currentUser) {
      toast.error('Please login to place an order');
      return;
    }
    
    const newOrder: Order = {
      ...orderData,
      id: Math.floor(100000000 + Math.random() * 900000000).toString(),
      date: new Date().toISOString(),
      status: 'Pending',
      userId: currentUser.uid,
      userEmail: currentUser.email || '',
    };
    
    // UI Updates
    setCurrentOrder(newOrder);
    setCartItems([]);
    handleNavChange('success');

    // Firebase requires defined values. JSON serialization safely strips `undefined` fields.
    const cleanOrder = JSON.parse(JSON.stringify(newOrder));

    try {
      await setDoc(doc(db, 'orders', cleanOrder.id), cleanOrder);
      toast.success('Order placed successfully! 🎉', { duration: 4000 });
    } catch (error) {
      console.error(error);
      handleFirestoreError(error, OperationType.CREATE, `orders/${newOrder.id}`);
    }
  };

  const handleBackToHome = () => {
    handleNavChange('home', null);
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error(e);
    }
    setUserName(null);
    setUserEmail(null);
    toast.success('Logged out successfully');
  };

  const isAdmin = userEmail === 'murlimanohar7041@gmail.com';

  // Render different full-page views
  if (view === 'admin' && isAdmin) {
    return (
      <AdminDashboard 
        orders={orders}
        onUpdateOrderStatus={async (id: string, status: string) => {
          try {
            await updateDoc(doc(db, 'orders', id), { status });
          } catch (error) {
            handleFirestoreError(error, OperationType.UPDATE, `orders/${id}`);
          }
        }}
        onBack={() => setView('home')}
      />
    );
  }

  if (view === 'success') {
    return (
      <SuccessScreen 
        order={currentOrder}
        onViewOrders={() => setView('orders')}
        onBackToHome={handleBackToHome} 
      />
    );
  }

  if (view === 'checkout') {
    return (
      <CheckoutPage 
        cartItems={cartItems} 
        onBack={() => setView(selectedRestaurant ? 'menu' : 'home')} 
        onPlaceOrder={handlePlaceOrder} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#0a0a0a] pb-16 md:pb-0 font-sans text-gray-900 dark:text-gray-100 transition-colors duration-500">
      <Navbar 
        cartCount={cartCount} 
        onOpenCart={() => setIsCartOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
        onOpenOffers={() => handleNavChange('offers')}
        onGoHome={() => handleNavChange('home', null)}
        userName={userName}
        setView={(v) => handleNavChange(v)}
        setSearchQuery={setSearchQuery}
        onLogout={handleLogout}
        isAdmin={isAdmin}
      />
      <Toaster 
        position="bottom-center"
        toastOptions={{
          style: {
            background: document.documentElement.classList.contains('dark') ? '#333' : '#fff',
            color: document.documentElement.classList.contains('dark') ? '#fff' : '#333',
            borderRadius: '10px',
          },
        }}
      />
      <main>
        {isTransitioning ? (
          <SkeletonGrid />
        ) : (
          <>
            {view === 'menu' && selectedRestaurant && (
              <MenuPage 
                restaurant={selectedRestaurant} 
                onBack={() => handleNavChange('home', null)} 
                cartItems={cartItems}
                wishlistIds={wishlist}
                onAddToCart={handleAddToCart}
                onBuyNow={handleBuyNow}
                onProductClick={setSelectedProduct}
                onUpdateQuantity={handleUpdateQuantity}
                onToggleWishlist={(id) => {
                  setWishlist(prev => {
                    const isSaved = prev.includes(id);
                    if (isSaved) {
                      return prev.filter(i => i !== id);
                    } else {
                      return [...prev, id];
                    }
                  });
                }}
                onSearch={() => handleNavChange('search')}
              />
            )}
            
            {view === 'offers' && (
              <OffersPage 
                onSelectRestaurant={(restaurant) => handleNavChange('menu', restaurant)}
                onBack={() => handleNavChange('home')}
              />
            )}
            
            {view === 'orders' && (
              <OrdersPage 
                orders={orders}
                onBack={() => handleNavChange('home')}
                isAdmin={isAdmin}
              />
            )}

            {view === 'wishlist' && (
              <WishlistPage 
                wishlistIds={wishlist}
                onRemoveFromWishlist={(id) => setWishlist(prev => prev.filter(i => i !== id))}
                onAddToCart={handleAddToCart}
                onBuyNow={handleBuyNow}
                onProductClick={setSelectedProduct}
                onBack={() => handleNavChange('home')}
              />
            )}

            {view === 'search' && (
              <SearchPage 
                initialQuery={searchQuery}
                onBack={() => handleNavChange('home')}
                onAddToCart={handleAddToCart}
                onBuyNow={handleBuyNow}
                onProductClick={setSelectedProduct}
                wishlistIds={wishlist}
                onToggleWishlist={(id) => {
                  setWishlist(prev => {
                    const isSaved = prev.includes(id);
                    if (isSaved) {
                      return prev.filter(i => i !== id);
                    } else {
                      return [...prev, id];
                    }
                  });
                }}
              />
            )}

            {view === 'home' && (
              <>
                <Hero setView={(v) => handleNavChange(v)} setSearchQuery={setSearchQuery} />
                <Banners setView={(v) => handleNavChange(v)} setSearchQuery={setSearchQuery} />
                <Categories setView={(v) => handleNavChange(v)} setSearchQuery={setSearchQuery} />
                <ProductGrid 
                  onAddToCart={handleAddToCart}
                  onBuyNow={handleBuyNow}
                  onProductClick={setSelectedProduct}
                  wishlistIds={wishlist}
                  onToggleWishlist={(id) => {
                    setWishlist(prev => {
                      const isSaved = prev.includes(id);
                      if (isSaved) {
                        return prev.filter(i => i !== id);
                      } else {
                        return [...prev, id];
                      }
                    });
                  }}
                />
              </>
            )}
          </>
        )}
        {['home', 'search', 'menu', 'offers'].includes(view) && <Footer />}
      </main>
      <BottomNav 
        cartCount={cartCount} 
        onOpenCart={() => setIsCartOpen(true)} 
        onOpenProfile={() => setIsProfileOpen(true)} 
        onGoHome={() => handleNavChange('home', null)}
        onOpenWishlist={() => handleNavChange('wishlist', null)}
        activeView={view}
      />
      
      <CartPanel 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onCheckout={handleCheckout}
      />
      
      <ProfileModal 
        isOpen={isProfileOpen} 
        onClose={() => setIsProfileOpen(false)} 
        onLogin={handleLogin}
      />
      
      <MobileMenu 
        isOpen={isMobileMenuOpen} 
        onClose={() => setIsMobileMenuOpen(false)} 
        onOpenProfile={() => setIsProfileOpen(true)}
        userName={userName}
        onLogout={handleLogout}
        setView={setView}
        isAdmin={isAdmin}
      />

      <AnimatePresence>
        {selectedProduct && (
          <ProductModal
            product={selectedProduct}
            onClose={() => setSelectedProduct(null)}
            onAddToCart={handleAddToCart}
            onBuyNow={handleBuyNow}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
